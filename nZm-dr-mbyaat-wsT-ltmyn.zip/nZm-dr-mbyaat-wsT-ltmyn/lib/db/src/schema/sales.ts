import {
  boolean,
  date,
  index,
  integer,
  jsonb,
  numeric,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";

export const usersTable = pgTable("sales_users", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  role: text("role").notNull().default("sales_executive"),
  branch: text("branch").notNull().default("غير محدد"),
  team: text("team").notNull().default("غير محدد"),
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const clientsTable = pgTable(
  "sales_clients",
  {
    id: serial("id").primaryKey(),
    name: text("name").notNull(),
    clientType: text("client_type").notNull(),
    companyName: text("company_name"),
    email: text("email"),
    phone: text("phone"),
    source: text("source").notNull().default("مباشر"),
    branch: text("branch").notNull(),
    team: text("team").notNull(),
    ownerId: text("owner_id").notNull(),
    ownerName: text("owner_name").notNull(),
    premium: numeric("premium", { precision: 14, scale: 2, mode: "number" }).notNull().default(0),
    activePolicies: integer("active_policies").notNull().default(0),
    lastContactAt: timestamp("last_contact_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    index("sales_clients_owner_idx").on(table.ownerId),
    index("sales_clients_scope_idx").on(table.branch, table.team),
  ],
);

export const opportunitiesTable = pgTable(
  "sales_opportunities",
  {
    id: serial("id").primaryKey(),
    title: text("title").notNull(),
    clientId: integer("client_id"),
    clientName: text("client_name").notNull(),
    product: text("product").notNull(),
    stage: text("stage").notNull().default("lead"),
    premium: numeric("premium", { precision: 14, scale: 2, mode: "number" }).notNull().default(0),
    probability: integer("probability").notNull().default(10),
    source: text("source").notNull().default("مباشر"),
    ownerId: text("owner_id").notNull(),
    ownerName: text("owner_name").notNull(),
    branch: text("branch").notNull(),
    team: text("team").notNull(),
    closeDate: date("close_date", { mode: "string" }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    index("sales_opportunities_owner_idx").on(table.ownerId),
    index("sales_opportunities_scope_idx").on(table.branch, table.team),
    index("sales_opportunities_stage_idx").on(table.stage),
  ],
);

export const tasksTable = pgTable(
  "sales_tasks",
  {
    id: serial("id").primaryKey(),
    title: text("title").notNull(),
    taskType: text("task_type").notNull().default("follow_up"),
    status: text("status").notNull().default("open"),
    priority: text("priority").notNull().default("medium"),
    dueAt: timestamp("due_at", { withTimezone: true }).notNull(),
    clientId: integer("client_id"),
    clientName: text("client_name"),
    ownerId: text("owner_id").notNull(),
    ownerName: text("owner_name").notNull(),
    branch: text("branch").notNull(),
    team: text("team").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    index("sales_tasks_owner_idx").on(table.ownerId),
    index("sales_tasks_status_due_idx").on(table.status, table.dueAt),
  ],
);

export const quotesTable = pgTable(
  "sales_quotes",
  {
    id: serial("id").primaryKey(),
    clientId: integer("client_id"),
    clientName: text("client_name").notNull(),
    product: text("product").notNull(),
    insurer: text("insurer").notNull(),
    premium: numeric("premium", { precision: 14, scale: 2, mode: "number" }).notNull().default(0),
    status: text("status").notNull().default("requested"),
    ownerId: text("owner_id").notNull(),
    ownerName: text("owner_name").notNull(),
    branch: text("branch").notNull(),
    team: text("team").notNull(),
    requestedAt: timestamp("requested_at", { withTimezone: true }).notNull().defaultNow(),
    expiresAt: timestamp("expires_at", { withTimezone: true }),
  },
  (table) => [
    index("sales_quotes_owner_idx").on(table.ownerId),
    index("sales_quotes_status_idx").on(table.status),
  ],
);

export const renewalsTable = pgTable(
  "sales_renewals",
  {
    id: serial("id").primaryKey(),
    clientId: integer("client_id"),
    clientName: text("client_name").notNull(),
    policyNumber: text("policy_number").notNull(),
    product: text("product").notNull(),
    renewalDate: date("renewal_date", { mode: "string" }).notNull(),
    premium: numeric("premium", { precision: 14, scale: 2, mode: "number" }).notNull().default(0),
    status: text("status").notNull().default("upcoming"),
    ownerId: text("owner_id").notNull(),
    ownerName: text("owner_name").notNull(),
    branch: text("branch").notNull(),
    team: text("team").notNull(),
  },
  (table) => [
    index("sales_renewals_owner_idx").on(table.ownerId),
    index("sales_renewals_date_idx").on(table.renewalDate),
  ],
);

export const commissionsTable = pgTable(
  "sales_commissions",
  {
    id: serial("id").primaryKey(),
    employeeId: text("employee_id").notNull(),
    employeeName: text("employee_name").notNull(),
    clientName: text("client_name").notNull(),
    policyNumber: text("policy_number").notNull(),
    grossAmount: numeric("gross_amount", { precision: 14, scale: 2, mode: "number" }).notNull().default(0),
    netAmount: numeric("net_amount", { precision: 14, scale: 2, mode: "number" }).notNull().default(0),
    status: text("status").notNull().default("pending"),
    period: text("period").notNull(),
  },
  (table) => [index("sales_commissions_employee_idx").on(table.employeeId)],
);

export const targetsTable = pgTable(
  "sales_targets",
  {
    id: serial("id").primaryKey(),
    employeeId: text("employee_id").notNull(),
    period: text("period").notNull(),
    premiumTarget: numeric("premium_target", { precision: 14, scale: 2, mode: "number" }).notNull().default(0),
    incentiveRate: numeric("incentive_rate", { precision: 6, scale: 3, mode: "number" }).notNull().default(0),
  },
  (table) => [uniqueIndex("sales_targets_employee_period_idx").on(table.employeeId, table.period)],
);

export const approvalsTable = pgTable("sales_approvals", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  requestType: text("request_type").notNull(),
  entityId: integer("entity_id").notNull(),
  amount: numeric("amount", { precision: 14, scale: 2, mode: "number" }).notNull().default(0),
  requester: text("requester").notNull(),
  requesterId: text("requester_id").notNull(),
  branch: text("branch").notNull(),
  team: text("team").notNull(),
  status: text("status").notNull().default("pending"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const activitiesTable = pgTable(
  "sales_activities",
  {
    id: serial("id").primaryKey(),
    activityType: text("activity_type").notNull(),
    summary: text("summary").notNull(),
    clientId: integer("client_id"),
    clientName: text("client_name"),
    ownerId: text("owner_id").notNull(),
    ownerName: text("owner_name").notNull(),
    branch: text("branch").notNull(),
    team: text("team").notNull(),
    occurredAt: timestamp("occurred_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("sales_activities_owner_idx").on(table.ownerId)],
);

export const attachmentsTable = pgTable("sales_attachments", {
  id: serial("id").primaryKey(),
  activityId: integer("activity_id").notNull(),
  fileName: text("file_name").notNull(),
  contentType: text("content_type").notNull(),
  sizeBytes: integer("size_bytes").notNull(),
  objectPath: text("object_path").notNull(),
  uploadedBy: text("uploaded_by").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const auditEntriesTable = pgTable(
  "sales_audit_entries",
  {
    id: serial("id").primaryKey(),
    actorId: text("actor_id").notNull(),
    actor: text("actor").notNull(),
    action: text("action").notNull(),
    entityType: text("entity_type").notNull(),
    entityId: integer("entity_id").notNull(),
    details: jsonb("details").notNull().default({}),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("sales_audit_created_idx").on(table.createdAt)],
);

export const leadSourcesTable = pgTable(
  "sales_lead_sources",
  {
    id: serial("id").primaryKey(),
    name: text("name").notNull(),
    sourceType: text("source_type").notNull().default("other"),
    active: boolean("active").notNull().default(true),
  },
  (table) => [uniqueIndex("sales_lead_sources_name_idx").on(table.name)],
);

export const businessIntegrationsTable = pgTable("sales_business_integrations", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  purpose: text("purpose").notNull(),
  status: text("status").notNull().default("not_connected"),
  lastSyncAt: timestamp("last_sync_at", { withTimezone: true }),
});
