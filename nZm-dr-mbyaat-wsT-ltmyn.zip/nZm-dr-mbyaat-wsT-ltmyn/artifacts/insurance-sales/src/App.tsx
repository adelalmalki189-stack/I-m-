import { useEffect, useMemo, useRef, useState, type FormEvent, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import * as API from '@workspace/api-client-react';
import { ClerkProvider, Show, SignIn, SignUp, useClerk, useUser } from '@clerk/react';
import { publishableKeyFromHost } from '@clerk/shared/keys';
import { shadcn } from '@clerk/themes';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Link, Route, Switch, Router as WouterRouter, useLocation } from 'wouter';
import {
  Activity, ArrowDownToLine, ArrowLeft, Bell, BriefcaseBusiness, Building2, CalendarClock,
  ChevronDown, CircleHelp, Clock3, FileCheck2, FilePlus2, Filter,
  Gauge, HandCoins, History, LayoutDashboard, LifeBuoy, LogOut, Menu, MoreHorizontal, Plus,
  Search, Settings2, ShieldCheck, SlidersHorizontal, Sparkles, Users, X, XCircle, Zap,
} from 'lucide-react';

const queryClient = new QueryClient({ defaultOptions: { queries: { retry: 1, staleTime: 20_000, refetchOnWindowFocus: false } } });
const clerkPubKey = publishableKeyFromHost(window.location.hostname, import.meta.env.VITE_CLERK_PUBLISHABLE_KEY);
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;
const basePath = import.meta.env.BASE_URL.replace(/\/$/, '');
function stripBase(path: string) { return basePath && path.startsWith(basePath) ? path.slice(basePath.length) || '/' : path; }
if (!clerkPubKey) throw new Error('Missing VITE_CLERK_PUBLISHABLE_KEY in .env file');

const appearance = {
  theme: shadcn, cssLayerName: 'clerk',
  options: { logoPlacement: 'inside' as const, logoLinkUrl: basePath || '/', logoImageUrl: `${window.location.origin}${basePath}/logo.svg` },
  variables: {
    colorPrimary: '#245f59', colorForeground: '#173b37', colorMutedForeground: '#69807a', colorDanger: '#b5463d',
    colorBackground: '#fffdf8', colorInput: '#f8f7f1', colorInputForeground: '#173b37', colorNeutral: '#deddd3',
    fontFamily: "'IBM Plex Sans Arabic', sans-serif", borderRadius: '0.8rem',
  },
  elements: {
    rootBox: 'w-full flex justify-center', cardBox: 'bg-[#fffdf8] rounded-2xl w-[440px] max-w-full overflow-hidden shadow-xl',
    card: '!shadow-none !border-0 !bg-transparent !rounded-none', footer: '!shadow-none !border-0 !bg-transparent !rounded-none',
    headerTitle: '!text-[#173b37] !font-bold', headerSubtitle: '!text-[#69807a]', socialButtonsBlockButtonText: '!text-[#173b37]',
    formFieldLabel: '!text-[#244a44]', footerActionLink: '!text-[#245f59]', footerActionText: '!text-[#69807a]',
    dividerText: '!text-[#69807a]', identityPreviewEditButton: '!text-[#245f59]', formFieldSuccessText: '!text-[#245f59]',
    alertText: '!text-[#9d3832]', logoBox: 'mb-3', logoImage: 'w-10 h-10', socialButtonsBlockButton: '!border-[#deddd3] !bg-[#fffdf8]',
    formButtonPrimary: '!bg-[#245f59] hover:!bg-[#174c46]', formFieldInput: '!bg-[#f8f7f1] !border-[#deddd3]',
    footerAction: '!bg-transparent', dividerLine: '!bg-[#deddd3]', alert: '!bg-[#fbefed]', otpCodeFieldInput: '!border-[#deddd3]',
    formFieldRow: 'mb-4', main: 'px-8',
  },
};

const modules = [
  { label: 'نظرة عامة', href: '/', icon: LayoutDashboard, group: 'المساحة اليومية' },
  { label: 'العملاء', href: '/clients', icon: Users, group: 'المساحة اليومية' },
  { label: 'الفرص البيعية', href: '/opportunities', icon: Gauge, group: 'المساحة اليومية' },
  { label: 'المتابعات', href: '/tasks', icon: CalendarClock, group: 'المساحة اليومية' },
  { label: 'عروض الأسعار', href: '/quotes', icon: FilePlus2, group: 'الإنتاج' },
  { label: 'التجديدات', href: '/renewals', icon: Clock3, group: 'الإنتاج' },
  { label: 'العمولات والأهداف', href: '/commissions', icon: HandCoins, group: 'الإنتاج' },
  { label: 'الموافقات', href: '/approvals', icon: FileCheck2, group: 'الإنتاج' },
  { label: 'سجل الأنشطة', href: '/activities', icon: Activity, group: 'الحوكمة' },
  { label: 'التقارير', href: '/reports', icon: BriefcaseBusiness, group: 'الحوكمة' },
  { label: 'سجل التدقيق', href: '/audit', icon: History, group: 'الحوكمة' },
  { label: 'المستخدمون والأدوار', href: '/users', icon: ShieldCheck, group: 'الإدارة' },
  { label: 'التكاملات', href: '/settings/integrations', icon: Settings2, group: 'الإدارة' },
];
const titles: Record<string, string> = Object.fromEntries(modules.map(x => [x.href, x.label]));
const roleNames: Record<string, string> = { system_admin: 'مدير النظام', sales_manager: 'مدير المبيعات', team_leader: 'قائد فريق', sales_executive: 'تنفيذي مبيعات', business_development: 'تطوير الأعمال', pricing_officer: 'مسؤول التسعير', finance: 'المالية', top_management: 'الإدارة العليا' };
const labels: Record<string, string> = {
  lead: 'عميل محتمل', qualified: 'مؤهلة', quotation: 'تسعير', negotiation: 'تفاوض', won: 'مكتسبة', lost: 'مفقودة',
  open: 'مفتوحة', in_progress: 'قيد التنفيذ', completed: 'مكتملة', overdue: 'متأخرة',
  requested: 'مطلوب', pricing: 'قيد التسعير', ready: 'جاهز', negotiating: 'تفاوض', accepted: 'مقبول', declined: 'مرفوض',
  upcoming: 'قادمة', renewed: 'تم التجديد', at_risk: 'معرّضة للخطر', pending: 'بانتظار الإجراء', approved: 'معتمد', rejected: 'مرفوض',
  matched: 'مطابقة', paid: 'مدفوعة', connected: 'متصل', attention: 'يتطلب الانتباه', not_connected: 'غير متصل',
  individual: 'فرد', company: 'شركة', call: 'مكالمة', meeting: 'اجتماع', follow_up: 'متابعة', document: 'مستند', other: 'أخرى',
  high: 'عالية', medium: 'متوسطة', low: 'منخفضة', email: 'بريد إلكتروني', note: 'ملاحظة', stage_change: 'تغيير مرحلة',
};
const money = (n?: number) => new Intl.NumberFormat('ar-SA', { style: 'currency', currency: 'SAR', maximumFractionDigits: 0 }).format(n || 0);
const dateFmt = (d?: string | null) => d ? new Intl.DateTimeFormat('ar-SA', { day: 'numeric', month: 'short', year: 'numeric' }).format(new Date(d)) : '—';
const todayFmt = () => new Intl.DateTimeFormat('ar-SA', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }).format(new Date());
const human = (value: unknown) => labels[String(value)] || String(value ?? '—');
const cellVal = (v: unknown) => typeof v === 'number' ? v.toLocaleString('ar-SA') : human(v);

function Logo({ inverse = false }: { inverse?: boolean }) {
  return <div className="flex items-center gap-3" dir="rtl"><span className={`grid size-10 place-items-center rounded-xl ${inverse ? 'bg-[hsl(var(--sidebar-primary))] text-[hsl(var(--sidebar))]' : 'bg-primary text-primary-foreground'}`}><ShieldCheck size={21}/></span><span><b className={`block text-[15px] font-bold leading-tight ${inverse ? 'text-sidebar-foreground' : ''}`}>وثاق</b><small className={`text-[10px] tracking-wide ${inverse ? 'text-sidebar-foreground/55' : 'text-muted-foreground'}`}>وساطة التأمين</small></span></div>;
}
function LoadingPanel() { return <div className="space-y-4 animate-pulse"><div className="h-8 w-48 rounded bg-secondary"/><div className="h-28 rounded-2xl bg-secondary"/><div className="h-64 rounded-2xl bg-secondary"/></div>; }
function QueryState({ loading, error, retry, children }: { loading: boolean; error: boolean; retry: () => void; children: ReactNode }) {
  if (loading) return <LoadingPanel/>;
  if (error) return <div className="rounded-2xl border border-destructive/20 bg-card p-12 text-center"><CircleHelp className="mx-auto mb-3 text-destructive"/><h3 className="font-bold">تعذّر تحميل البيانات</h3><p className="my-2 text-sm text-muted-foreground">تحقق من اتصالك ثم أعد المحاولة.</p><button onClick={retry} className="mt-2 rounded-lg bg-primary px-4 py-2 text-sm text-primary-foreground">إعادة المحاولة</button></div>;
  return <>{children}</>;
}
function StatusPill({ status }: { status: unknown }) {
  const key = String(status || '');
  const tone = ['won','completed','paid','approved','accepted','renewed','connected'].includes(key) ? 'bg-emerald-50 text-emerald-800 ring-emerald-200' :
    ['overdue','lost','rejected','declined','at_risk','attention'].includes(key) ? 'bg-rose-50 text-rose-800 ring-rose-200' :
    ['in_progress','negotiation','negotiating','pricing','matched'].includes(key) ? 'bg-amber-50 text-amber-900 ring-amber-200' : 'bg-stone-100 text-stone-700 ring-stone-200';
  return <span className={`inline-flex whitespace-nowrap rounded-full px-2.5 py-1 text-[11px] font-semibold ring-1 ring-inset ${tone}`}>{human(status)}</span>;
}

function SignInPage() {
  return <div className="relative flex min-h-[100dvh] items-center justify-center overflow-hidden bg-[#f1f0e7] px-4 py-10"><div className="absolute -right-20 -top-20 size-80 rounded-full border border-primary/10"/><div className="absolute -left-20 bottom-0 size-96 rounded-full border border-primary/10"/><div className="relative z-10"><div className="mb-6 flex justify-center"><Logo/></div><SignIn routing="path" path={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`}/></div></div>;
}
function SignUpPage() {
  return <div className="relative flex min-h-[100dvh] items-center justify-center overflow-hidden bg-[#f1f0e7] px-4 py-10"><div className="absolute -right-20 -top-20 size-80 rounded-full border border-primary/10"/><div className="absolute -left-20 bottom-0 size-96 rounded-full border border-primary/10"/><div className="relative z-10"><div className="mb-6 flex justify-center"><Logo/></div><SignUp routing="path" path={`${basePath}/sign-up`} signInUrl={`${basePath}/sign-in`}/></div></div>;
}
function Landing() {
  return <div dir="rtl" className="min-h-[100dvh] overflow-hidden bg-[#f2f1e8] text-[#193d39]"><header className="mx-auto flex max-w-7xl items-center justify-between px-6 py-6"><Logo/><Link href="/sign-in" className="rounded-xl bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground transition hover:-translate-y-0.5">دخول مساحة العمل <ArrowLeft className="mr-2 inline size-4"/></Link></header><main className="mx-auto grid max-w-7xl items-center gap-10 px-6 pb-20 pt-12 md:grid-cols-[1.05fr_.95fr] md:pt-20"><div className="rise"><span className="mb-7 inline-flex items-center gap-2 rounded-full border border-primary/15 bg-white/60 px-4 py-2 text-xs font-semibold text-primary"><Sparkles size={14}/> مكتب المبيعات الذي يحفظ كل التفاصيل</span><h1 className="max-w-3xl text-5xl font-bold leading-[1.3] tracking-tight md:text-7xl">علاقة أوثق.<br/><span className="text-[#c29148]">قرار أوضح.</span></h1><p className="mt-7 max-w-xl text-lg leading-9 text-[#607570]">من أول تواصل مع العميل حتى تجديد وثيقته، مساحة تشغيل واحدة توضح المسؤولية وتحفظ أثر كل خطوة.</p><div className="mt-9 flex flex-wrap gap-3"><Link href="/sign-in" className="rounded-xl bg-primary px-6 py-4 font-semibold text-primary-foreground shadow-lg shadow-primary/10 transition hover:-translate-y-1">ابدأ يومك البيعي <ArrowLeft className="mr-2 inline size-4"/></Link><a href="#principles" className="rounded-xl border border-primary/20 bg-white/60 px-6 py-4 font-semibold">اكتشف المساحة</a></div><div className="mt-12 flex items-center gap-8 border-t border-primary/10 pt-6 text-sm"><div><b className="block text-xl">كل عميل</b><span className="text-[#71847e]">له مالك واضح</span></div><div><b className="block text-xl">كل ريال</b><span className="text-[#71847e]">له أثر محفوظ</span></div><div><b className="block text-xl">كل موعد</b><span className="text-[#71847e]">في وقته المناسب</span></div></div></div><div className="relative mx-auto w-full max-w-xl rise"><div className="absolute -inset-7 rounded-[2.5rem] bg-[#d9e4db] rotate-3"/><section className="relative rounded-[2rem] border border-white/80 bg-[#fffdf8] p-6 shadow-[0_30px_80px_rgba(23,60,55,.14)]"><div className="flex items-center justify-between"><div><small className="text-muted-foreground">ملخص أداء الفرع</small><h2 className="mt-1 text-xl font-bold">الأحد، ١٦ يونيو</h2></div><span className="grid size-11 place-items-center rounded-2xl bg-[#f4ead7] text-[#9a7137]"><Gauge/></span></div><div className="mt-7 grid grid-cols-2 gap-3"><div className="rounded-2xl bg-[#edf3ef] p-4"><small className="text-muted-foreground">قيمة الفرص</small><b className="mt-2 block text-2xl">١٫٢٨ م <small className="text-xs">ر.س</small></b><span className="mt-2 block text-xs text-emerald-700">↑ نمو صحي في المسار</span></div><div className="rounded-2xl bg-[#f7f0e2] p-4"><small className="text-muted-foreground">متابعات اليوم</small><b className="mt-2 block text-2xl">١٨</b><span className="mt-2 block text-xs text-[#8e6b34]">٦ منها أولوية عالية</span></div></div><div className="mt-5 rounded-2xl border border-border p-4"><div className="mb-4 flex items-center justify-between"><b>مسار الفرص</b><span className="text-xs text-muted-foreground">توزيع القيمة</span></div>{[['تأهيل',72],['تسعير',58],['تفاوض',34]].map(([l,w])=><div key={l} className="mb-3 flex items-center gap-3 text-xs"><span className="w-14">{l}</span><span className="h-2 flex-1 overflow-hidden rounded-full bg-secondary"><i className="block h-full rounded-full bg-primary" style={{width:`${w}%`}}/></span><b>{w}%</b></div>)}</div><div className="mt-4 flex items-center gap-3 rounded-2xl bg-[#173e39] p-4 text-white"><span className="grid size-9 place-items-center rounded-xl bg-white/10"><Bell size={16}/></span><div className="flex-1"><b className="block text-sm">موعد تجديد قريب</b><small className="text-white/60">شركة مدار · تأمين طبي جماعي</small></div><ArrowLeft size={16}/></div></section></div></main><section id="principles" className="border-y border-primary/10 bg-[#e8ede4] px-6 py-16"><div className="mx-auto grid max-w-7xl gap-10 md:grid-cols-3">{[['01','الملكية لا تُفترض','كل ملف مرتبط بمسؤول وفريق وفرع. تتبع واضح من أول فرصة إلى إقفالها.'],['02','الأرقام لها سياق','قيمة القسط والعمولة والهدف تظهر بجانب القرار الذي يخصها.'],['03','لا تفوت المتابعة','التذكيرات والتجديدات والموافقات في قلب مساحة العمل، لا في مكان جانبي.']].map(([n,t,d])=><article key={n} className="border-r border-primary/15 pr-5"><span className="font-mono text-sm text-[#bb8f4d]">{n}</span><h3 className="mt-3 text-xl font-bold">{t}</h3><p className="mt-3 leading-7 text-[#687c76]">{d}</p></article>)}</div></section><footer className="mx-auto flex max-w-7xl items-center justify-between px-6 py-7 text-xs text-[#75847f]"><Logo/><span>مساحة تشغيل موثوقة لفرق وساطة التأمين</span></footer></div>;
}

type AnyRow = Record<string, any>;
type ModalKind = 'client' | 'opportunity' | 'task' | 'quote' | 'activity' | null;
function Workspace() {
  const [path] = useLocation();
  const qc = useQueryClient();
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('all');
  const [modal, setModal] = useState<ModalKind>(null);
  const [quoteStep, setQuoteStep] = useState(1);
  const [noticeOpen, setNoticeOpen] = useState(false);
  const [mobileNav, setMobileNav] = useState(false);
  const [selectedClientId, setSelectedClientId] = useState<number | null>(null);
  const [form, setForm] = useState<AnyRow>({});
  const { user: clerkUser } = useUser();
  const clients = API.useListClients(search ? { search } : undefined);
  const opportunities = API.useListOpportunities(search ? { search } : undefined);
  const tasks = API.useListTasks(undefined, { query: { queryKey: API.getListTasksQueryKey(), refetchInterval: 60_000, refetchOnWindowFocus: true } });
  const quotes = API.useListQuotes();
  const renewals = API.useListRenewals();
  const commissions = API.useListCommissions();
  const approvals = API.useListApprovals();
  const activities = API.useListActivities();
  const audit = API.useListAuditEntries();
  const users = API.useListUsers();
  const integrations = API.useListIntegrations();
  const reports = API.useGetReports();
  const dash = API.useGetDashboard({ query: { queryKey: API.getGetDashboardQueryKey(), refetchInterval: 60_000, refetchOnWindowFocus: true } });
  const selectedClient = API.useGetClient(selectedClientId || 0, { query: { enabled: !!selectedClientId, queryKey: API.getGetClientQueryKey(selectedClientId || 0) } });
  const createClient = API.useCreateClient();
  const updateClient = API.useUpdateClient();
  const deleteClient = API.useDeleteClient();
  const createOpportunity = API.useCreateOpportunity();
  const updateOpportunity = API.useUpdateOpportunity();
  const createTask = API.useCreateTask();
  const updateTask = API.useUpdateTask();
  const createQuote = API.useCreateQuote();
  const updateQuote = API.useUpdateQuote();
  const updateRenewal = API.useUpdateRenewal();
  const updateApproval = API.useUpdateApproval();
  const createActivity = API.useCreateActivity();
  const updateUserRole = API.useUpdateUserRole();
  const { signOut } = useClerk();
  const pageName = titles[path] || 'نظرة عامة';
  const currentAppUser = (users.data || []).find((u: any) => u.id === clerkUser?.id || u.email === clerkUser?.primaryEmailAddress?.emailAddress) as any;
  const managerRoles = ['system_admin','sales_manager','team_leader','top_management'];
  const visibility: Record<string, string[]> = {
    '/approvals': ['system_admin','sales_manager','team_leader','pricing_officer','finance'],
    '/commissions': ['system_admin','sales_manager','team_leader','sales_executive','finance','top_management'],
    '/audit': ['system_admin','sales_manager','top_management'], '/users': ['system_admin','sales_manager'],
    '/settings/integrations': ['system_admin'], '/reports': ['system_admin','sales_manager','business_development','finance','top_management'],
  };
  const navModules = currentAppUser?.role ? modules.filter(m => !visibility[m.href] || visibility[m.href].includes(currentAppUser.role) || managerRoles.includes(currentAppUser.role)) : modules;
  const groupNames = [...new Set(navModules.map(x => x.group))];
  const currentQuery = path === '/' ? dash : path === '/clients' ? clients : path === '/opportunities' ? opportunities : path === '/tasks' ? tasks : path === '/quotes' ? quotes : path === '/renewals' ? renewals : path === '/commissions' ? commissions : path === '/approvals' ? approvals : path === '/activities' ? activities : path === '/audit' ? audit : path === '/users' ? users : path === '/reports' ? reports : integrations;
  const loading = !!currentQuery.isLoading;
  const error = !!currentQuery.isError;
  const records = (Array.isArray(currentQuery.data) ? currentQuery.data : []) as AnyRow[];
  const openModal = (which: ModalKind, row?: AnyRow) => { setModal(which); setQuoteStep(1); setForm(row || {}); setSelectedClientId(which === 'client' && row?.id ? row.id : null); };
  useEffect(() => {
    if (modal === 'client' && selectedClient.data && selectedClientId === selectedClient.data.id) setForm(selectedClient.data as AnyRow);
  }, [modal, selectedClient.data, selectedClientId]);
  const invalidate = (...keys: any[]) => keys.forEach(key => qc.invalidateQueries({ queryKey: key }));
  const openTasks = (dash.data?.dueTasks || tasks.data || []) as AnyRow[];
  const safeSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (modal === 'client') {
      const payload = { name: form.name || '', clientType: form.clientType || 'company', companyName: form.companyName || '', email: form.email || '', phone: form.phone || '', source: form.source || 'إحالة', branch: form.branch || 'الرياض', team: form.team || 'الفريق الأول', premium: Number(form.premium || 0), activePolicies: Number(form.activePolicies || 0) };
      const done = (updated?: any) => { invalidate(API.getListClientsQueryKey(), API.getGetDashboardQueryKey()); if (updated?.id) invalidate(API.getGetClientQueryKey(updated.id)); setModal(null); };
      if (form.id) updateClient.mutate({ id: form.id, data: payload }, { onSuccess: done }); else createClient.mutate({ data: payload }, { onSuccess: done });
    }
    if (modal === 'opportunity') {
      const payload = { title: form.title || '', clientName: form.clientName || '', clientId: form.clientId ? Number(form.clientId) : undefined, product: form.product || 'تأمين طبي', stage: form.stage || 'lead', premium: Number(form.premium || 0), probability: Number(form.probability || 20), source: form.source || 'إحالة', branch: form.branch || 'الرياض', team: form.team || 'الفريق الأول', closeDate: form.closeDate || undefined };
      createOpportunity.mutate({ data: payload }, { onSuccess: () => { invalidate(API.getListOpportunitiesQueryKey(), API.getGetDashboardQueryKey()); setModal(null); } });
    }
    if (modal === 'task') {
      const payload = { title: form.title || '', taskType: form.taskType || 'follow_up', status: 'open' as const, priority: form.priority || 'medium', dueAt: form.dueAt || new Date().toISOString(), clientName: form.clientName || '', clientId: form.clientId ? Number(form.clientId) : undefined };
      createTask.mutate({ data: payload }, { onSuccess: () => { invalidate(API.getListTasksQueryKey(), API.getGetDashboardQueryKey()); setModal(null); } });
    }
    if (modal === 'activity') {
      createActivity.mutate({ data: { activityType: form.activityType || 'note', summary: form.summary || '', clientName: form.clientName || '', clientId: form.clientId ? Number(form.clientId) : undefined } }, { onSuccess: () => { invalidate(API.getListActivitiesQueryKey(), API.getGetDashboardQueryKey()); setModal(null); } });
    }
    if (modal === 'quote' && quoteStep < 3) { setQuoteStep(quoteStep + 1); return; }
    if (modal === 'quote') {
      createQuote.mutate({ data: { clientName: form.clientName || '', clientId: form.clientId ? Number(form.clientId) : undefined, product: form.product || 'تأمين طبي', insurer: form.insurer || 'التعاونية', premium: Number(form.premium || 0), status: 'requested', expiresAt: form.expiresAt || undefined } }, { onSuccess: () => { invalidate(API.getListQuotesQueryKey()); setModal(null); } });
    }
  };
  const mutationPending = createClient.isPending || updateClient.isPending || createOpportunity.isPending || createTask.isPending || createQuote.isPending || createActivity.isPending;
  const filtered = useMemo(() => records.filter(row => filter === 'all' || String(row.status || row.stage || '') === filter), [records, filter]);
  const exportCsv = () => {
    const rows = filtered.length ? filtered : records;
    const columns = Object.keys(rows[0] || {});
    const csv = [columns.join(','), ...rows.map(row => columns.map(k => `"${String(row[k] ?? '').replaceAll('"','""')}"`).join(','))].join('\n');
    const url = URL.createObjectURL(new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8' }));
    const a = document.createElement('a'); a.href = url; a.download = `${path.replaceAll('/','-').replace(/^-/, '') || 'dashboard'}.csv`; a.click(); URL.revokeObjectURL(url);
  };
  type OpportunityStage = 'lead' | 'qualified' | 'quotation' | 'negotiation' | 'won' | 'lost';
  const mutateStage = (id: number, stage: OpportunityStage) => updateOpportunity.mutate({ id, data: { stage } }, { onSuccess: () => invalidate(API.getListOpportunitiesQueryKey(), API.getGetDashboardQueryKey()) });
  const moveTask = (row: AnyRow) => updateTask.mutate({ id: row.id, data: { status: row.status === 'completed' ? 'open' : 'completed' } }, { onSuccess: () => invalidate(API.getListTasksQueryKey(), API.getGetDashboardQueryKey()) });
  const titleByPath: Record<string, string[]> = {
    '/clients': ['العميل', 'نوع العميل', 'رقم التواصل', 'المالك', 'الأقساط السنوية', 'الوثائق', 'آخر تواصل'],
    '/opportunities': ['الفرصة', 'العميل', 'المنتج', 'المرحلة', 'القسط المتوقع', 'احتمالية الفوز', 'المسؤول'],
    '/tasks': ['المتابعة', 'العميل', 'النوع', 'الأولوية', 'الموعد', 'الحالة', 'المسؤول'],
    '/quotes': ['العميل', 'المنتج', 'شركة التأمين', 'القسط', 'الحالة', 'المسؤول', 'تاريخ الطلب'],
    '/renewals': ['العميل', 'رقم الوثيقة', 'المنتج', 'موعد التجديد', 'القسط', 'الحالة', 'المسؤول'],
    '/commissions': ['الموظف', 'العميل', 'رقم الوثيقة', 'الإجمالي', 'الصافي', 'الحالة', 'الفترة'],
    '/approvals': ['الطلب', 'النوع', 'مقدم الطلب', 'المبلغ', 'تاريخ الطلب', 'الحالة', 'الإجراء'],
    '/activities': ['النشاط', 'الملخص', 'العميل', 'المسؤول', 'التاريخ والوقت'],
    '/audit': ['المنفذ', 'الإجراء', 'نوع السجل', 'المعرف', 'التاريخ والوقت'],
    '/users': ['المستخدم', 'البريد الإلكتروني', 'الدور', 'الفرع', 'الفريق', 'الحالة'],
    '/settings/integrations': ['التكامل', 'الغرض', 'الحالة', 'آخر مزامنة'],
  };
  const keysByPath: Record<string, string[]> = {
    '/clients': ['name','clientType','phone','ownerName','premium','activePolicies','lastContactAt'],
    '/opportunities': ['title','clientName','product','stage','premium','probability','ownerName'],
    '/tasks': ['title','clientName','taskType','priority','dueAt','status','ownerName'],
    '/quotes': ['clientName','product','insurer','premium','status','ownerName','requestedAt'],
    '/renewals': ['clientName','policyNumber','product','renewalDate','premium','status','ownerName'],
    '/commissions': ['employeeName','clientName','policyNumber','grossAmount','netAmount','status','period'],
    '/approvals': ['title','requestType','requester','amount','createdAt','status','id'],
    '/activities': ['activityType','summary','clientName','ownerName','occurredAt'],
    '/audit': ['actor','action','entityType','entityId','createdAt'],
    '/users': ['name','email','role','branch','team','active'],
    '/settings/integrations': ['name','purpose','status','lastSyncAt'],
  };
  const simpleTables = path !== '/' && path !== '/reports';

  function displayValue(row: AnyRow, key: string) {
    if (key === 'premium' || key === 'amount' || key === 'grossAmount' || key === 'netAmount') return money(row[key]);
    if (key.toLowerCase().includes('at') || key.toLowerCase().includes('date')) return dateFmt(row[key]);
    if (key === 'active') return row[key] ? 'نشط' : 'غير نشط';
    if (key === 'probability') return `${Number(row[key] || 0).toLocaleString('ar-SA')}٪`;
    return human(row[key]);
  }
  const getRowAction = (row: AnyRow) => {
    if (path === '/clients') return <div className="flex gap-1"><button aria-label="تعديل العميل" onClick={() => openModal('client', row)} className="rounded-lg p-2 text-muted-foreground hover:bg-secondary hover:text-foreground"><MoreHorizontal size={17}/></button><button aria-label="حذف العميل" onClick={() => { if (window.confirm(`حذف ملف ${row.name}؟`)) deleteClient.mutate({ id: row.id }, { onSuccess: () => invalidate(API.getListClientsQueryKey(), API.getGetDashboardQueryKey(), API.getGetClientQueryKey(row.id)) }); }} className="rounded-lg p-2 text-muted-foreground hover:bg-rose-50 hover:text-rose-700"><XCircle size={16}/></button></div>;
    if (path === '/tasks') return <button onClick={() => moveTask(row)} className="rounded-lg border border-border px-3 py-1.5 text-xs font-semibold hover:bg-secondary">{row.status === 'completed' ? 'إعادة فتح' : 'إنجاز'}</button>;
    if (path === '/approvals') return row.status === 'pending' ? <div className="flex gap-2"><button onClick={() => updateApproval.mutate({ id: row.id, data: { status: 'approved' } }, { onSuccess: () => invalidate(API.getListApprovalsQueryKey()) })} className="rounded-lg bg-primary px-3 py-1.5 text-xs text-primary-foreground">اعتماد</button><button onClick={() => updateApproval.mutate({ id: row.id, data: { status: 'rejected' } }, { onSuccess: () => invalidate(API.getListApprovalsQueryKey()) })} className="rounded-lg bg-secondary px-3 py-1.5 text-xs">رفض</button></div> : <StatusPill status={row.status}/>;
    if (path === '/users') return <select aria-label="تغيير دور المستخدم" value={row.role} onChange={e => updateUserRole.mutate({ id: row.id, data: { role: e.target.value as any } }, { onSuccess: () => invalidate(API.getListUsersQueryKey()) })} className="rounded-lg border border-border bg-card px-2 py-1 text-xs">{Object.entries(roleNames).map(([k,v]) => <option key={k} value={k}>{v}</option>)}</select>;
    if (path === '/renewals') return <select aria-label="تحديث حالة التجديد" value={row.status} onChange={e => updateRenewal.mutate({ id: row.id, data: { status: e.target.value as any } }, { onSuccess: () => invalidate(API.getListRenewalsQueryKey(), API.getGetDashboardQueryKey()) })} className="rounded-lg border border-border bg-card px-2 py-1 text-xs">{['upcoming','in_progress','renewed','at_risk','lost'].map(k=><option key={k} value={k}>{human(k)}</option>)}</select>;
    if (path === '/quotes') return <select aria-label="تحديث حالة العرض" value={row.status} onChange={e => updateQuote.mutate({ id: row.id, data: { status: e.target.value as any } }, { onSuccess: () => invalidate(API.getListQuotesQueryKey()) })} className="rounded-lg border border-border bg-card px-2 py-1 text-xs">{['requested','pricing','ready','negotiating','accepted','declined'].map(k=><option key={k} value={k}>{human(k)}</option>)}</select>;
    if (path === '/opportunities') return <select aria-label="تغيير مرحلة الفرصة" value={row.stage} onChange={e => mutateStage(row.id, e.target.value as OpportunityStage)} className="rounded-lg border border-border bg-card px-2 py-1 text-xs">{['lead','qualified','quotation','negotiation','won','lost'].map(k=><option key={k} value={k}>{human(k)}</option>)}</select>;
    return null;
  };
  const sectionIcon = modules.find(m => m.href === path)?.icon || LayoutDashboard;
  const PageIcon = sectionIcon;
  return <div dir="rtl" className="app-noise min-h-[100dvh] bg-background text-foreground">
    <aside className={`fixed inset-y-0 right-0 z-50 flex w-[258px] flex-col bg-sidebar text-sidebar-foreground transition-transform duration-300 md:translate-x-0 ${mobileNav ? 'translate-x-0' : 'translate-x-full md:translate-x-0'}`}>
      <div className="flex h-[82px] items-center justify-between border-b border-sidebar-border px-6"><Logo inverse/><button className="md:hidden" onClick={() => setMobileNav(false)}><X size={18}/></button></div>
      <div className="mx-4 mt-5 rounded-xl border border-sidebar-border bg-sidebar-accent/60 px-3 py-3"><div className="flex items-center justify-between"><span className="text-[10px] text-sidebar-foreground/50">مساحة العمل</span><ChevronDown size={14} className="text-sidebar-foreground/50"/></div><div className="mt-1 flex items-center gap-2 text-sm font-semibold"><Building2 size={15} className="text-[hsl(var(--sidebar-primary))]"/> فرع الرياض الرئيسي</div></div>
      <nav className="scrollbar-thin mt-5 flex-1 overflow-y-auto px-3 pb-5">{groupNames.map(group => <div key={group} className="mb-5"><div className="mb-2 px-3 text-[10px] font-semibold tracking-[.12em] text-sidebar-foreground/40">{group}</div>{navModules.filter(m => m.group === group).map(({ label, href, icon: Icon }) => <Link key={href} href={href} onClick={() => setMobileNav(false)} className={`mb-1 flex items-center gap-3 rounded-xl px-3 py-2.5 text-[13px] transition ${path === href ? 'bg-sidebar-accent text-sidebar-accent-foreground shadow-sm' : 'text-sidebar-foreground/70 hover:bg-sidebar-accent/70 hover:text-sidebar-foreground'}`}><Icon size={17} strokeWidth={path === href ? 2.3 : 1.8}/><span className="flex-1">{label}</span>{href === '/approvals' && (approvals.data?.filter((x:any)=>x.status==='pending').length || 0) > 0 && <span className="rounded-md bg-[hsl(var(--sidebar-primary))] px-1.5 py-0.5 text-[10px] font-bold text-sidebar">{approvals.data?.filter((x:any)=>x.status==='pending').length}</span>}</Link>)}</div>)}</nav>
      <div className="m-4 rounded-2xl border border-sidebar-border bg-sidebar-accent/50 p-3"><div className="flex items-center gap-2"><span className="grid size-8 place-items-center rounded-xl bg-sidebar-primary/15 text-sidebar-primary"><LifeBuoy size={16}/></span><div><b className="block text-xs">الدعم الداخلي</b><small className="text-[10px] text-sidebar-foreground/50">تواصل مع مسؤول الفرع للمساندة</small></div></div></div>
    </aside>
    {mobileNav && <button aria-label="إغلاق القائمة" onClick={() => setMobileNav(false)} className="fixed inset-0 z-40 bg-foreground/35 md:hidden"/>}
    <div className="min-h-[100dvh] md:mr-[258px]">
      <header className="sticky top-0 z-30 flex h-[72px] items-center gap-4 border-b border-border/80 bg-background/90 px-4 backdrop-blur-xl md:px-8">
        <button aria-label="فتح القائمة" onClick={() => setMobileNav(true)} className="rounded-lg p-2 hover:bg-secondary md:hidden"><Menu size={19}/></button>
        <div className="min-w-0 flex-1"><div className="flex items-center gap-2 text-xs text-muted-foreground"><span>وثاق</span><span>/</span><b className="truncate text-foreground">{pageName}</b></div><div className="mt-1 hidden text-[10px] text-muted-foreground sm:block">{todayFmt()} <span className="mx-1">·</span> مساحة العمليات اليومية</div></div>
        <label className="hidden h-10 max-w-[250px] flex-1 items-center gap-2 rounded-xl border border-border bg-card px-3 text-muted-foreground lg:flex"><Search size={16}/><input value={search} onChange={e => setSearch(e.target.value)} placeholder="ابحث في مساحة العمل" className="min-w-0 flex-1 bg-transparent text-xs outline-none placeholder:text-muted-foreground/70"/><kbd className="rounded border border-border px-1.5 py-0.5 text-[9px]">⌘ K</kbd></label>
        <div className="relative"><button aria-label="الإشعارات" onClick={() => setNoticeOpen(!noticeOpen)} className="relative grid size-10 place-items-center rounded-xl border border-border bg-card text-muted-foreground transition hover:bg-secondary"><Bell size={18}/>{openTasks.length > 0 && <i className="absolute left-2 top-2 size-2 rounded-full bg-[#bd7549] ring-2 ring-card"/>}</button>{noticeOpen && <div className="absolute left-0 top-12 z-50 w-[min(340px,90vw)] rounded-2xl border border-border bg-card p-4 shadow-lg"><div className="flex items-center justify-between"><b>تنبيهاتك اليوم</b><button onClick={() => setNoticeOpen(false)}><X size={16}/></button></div><p className="mt-1 text-xs text-muted-foreground">{openTasks.length} متابعة مستحقة أو قادمة</p><div className="mt-3 max-h-72 space-y-2 overflow-auto">{openTasks.slice(0,5).map((t:any)=><div key={t.id} className="rounded-xl bg-secondary/60 p-3"><b className="block text-xs">{t.title}</b><span className="text-[10px] text-muted-foreground">{t.clientName || 'بدون عميل مرتبط'} · {dateFmt(t.dueAt)}</span></div>)}{!openTasks.length && <p className="py-5 text-center text-xs text-muted-foreground">لا توجد تذكيرات الآن</p>}</div></div>}</div>
        <div className="hidden h-9 w-px bg-border sm:block"/><div className="hidden items-center gap-2 sm:flex"><span className="grid size-9 place-items-center rounded-full bg-[#dbe7df] text-xs font-bold text-primary">{(clerkUser?.fullName || clerkUser?.primaryEmailAddress?.emailAddress || 'م').slice(0,1)}</span><div><b className="block text-xs">{clerkUser?.fullName || clerkUser?.primaryEmailAddress?.emailAddress || 'حساب المستخدم'}</b><small className="text-[10px] text-muted-foreground">{currentAppUser?.role ? roleNames[currentAppUser.role] : 'مساحة مبيعات'}</small></div><button onClick={() => signOut({ redirectUrl: basePath || '/' })} aria-label="تسجيل الخروج" className="mr-1 rounded-lg p-2 text-muted-foreground hover:bg-secondary"><LogOut size={15}/></button></div>
      </header>
      <main className="mx-auto max-w-[1600px] px-4 py-6 md:px-8 md:py-8">
        {path === '/' ? <QueryState loading={loading} error={error} retry={() => dash.refetch()}>{<Dashboard data={dash.data} tasks={openTasks} greeting={clerkUser?.firstName || 'بك'}/>}</QueryState> :
        path === '/reports' ? <QueryState loading={loading} error={error} retry={() => reports.refetch()}><Reports data={reports.data}/></QueryState> :
        <QueryState loading={loading} error={error} retry={() => currentQuery.refetch()}>{simpleTables ? <TablePage path={path} pageName={pageName} icon={<PageIcon size={20}/>} rows={filtered} original={records} labels={titleByPath[path] || []} keys={keysByPath[path] || []} search={search} onSearch={setSearch} filter={filter} setFilter={setFilter} onExport={exportCsv} rowAction={getRowAction} onAdd={() => openModal(path === '/clients' ? 'client' : path === '/opportunities' ? 'opportunity' : path === '/tasks' ? 'task' : path === '/quotes' ? 'quote' : path === '/activities' ? 'activity' : null)} deletePending={deleteClient.isPending}/> : <Dashboard data={dash.data} tasks={openTasks} greeting={clerkUser?.firstName || 'بك'}/>}</QueryState>}
      </main>
    </div>
    {modal && <EntryModal kind={modal} form={form} setForm={setForm} close={() => setModal(null)} submit={safeSubmit} step={quoteStep} busy={mutationPending} clients={Array.isArray(clients.data) ? clients.data as any[] : []}/>}
  </div>;
}

function Dashboard({ data, tasks, greeting }: { data: any; tasks: AnyRow[]; greeting: string }) {
  const values = [
    { label: 'إجمالي العملاء', value: data?.totalClients, icon: Users, color: 'bg-[#e7f0ea] text-[#397365]', detail: 'ملفات ضمن نطاقك' },
    { label: 'الفرص المفتوحة', value: data?.openOpportunities, icon: Gauge, color: 'bg-[#f7eddb] text-[#a17a3f]', detail: money(data?.weightedPipeline) + ' قيمة مرجحة' },
    { label: 'إيراد هذا الشهر', value: money(data?.revenueThisMonth), icon: HandCoins, color: 'bg-[#e6edf0] text-[#45727b]', detail: 'من الوثائق المصدرة' },
    { label: 'تجديدات قريبة', value: data?.renewalsDue, icon: Clock3, color: 'bg-[#f5e9e4] text-[#a75d48]', detail: 'تحتاج إلى متابعة' },
  ];
  return <div className="space-y-7"><div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end"><div className="rise"><div className="mb-2 flex items-center gap-2 text-xs font-semibold text-primary"><span className="size-1.5 rounded-full bg-[#bf9a5a]"/> مساحة العمليات اليومية</div><h1 className="text-3xl font-bold tracking-tight md:text-[34px]">صباح الخير، {greeting}</h1><p className="mt-2 text-sm text-muted-foreground">إليك ما يستحق انتباهك اليوم في فرعك.</p></div><span className="inline-flex items-center gap-2 self-start rounded-xl border border-border bg-card px-3 py-2 text-xs text-muted-foreground sm:self-auto"><CalendarClock size={15}/> {todayFmt()}</span></div>
    <section className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">{values.map((item,i)=>{const I=item.icon;return <article key={item.label} className="rise rounded-2xl border border-card-border bg-card p-5 shadow-[var(--shadow-sm)]" style={{animationDelay:`${i*55}ms`}}><div className="flex items-center justify-between"><span className="text-xs font-medium text-muted-foreground">{item.label}</span><span className={`grid size-9 place-items-center rounded-xl ${item.color}`}><I size={17}/></span></div><b className="mt-4 block text-2xl font-bold tabular-nums">{item.value === undefined ? '—' : typeof item.value === 'number' ? item.value.toLocaleString('ar-SA') : item.value}</b><small className="mt-1 block text-[11px] text-muted-foreground">{item.detail}</small></article>})}</section>
    <section className="grid gap-5 xl:grid-cols-[1.45fr_.8fr]"><div className="rounded-2xl border border-card-border bg-card p-5 shadow-[var(--shadow-sm)] md:p-6"><div className="flex items-start justify-between"><div><span className="text-xs text-muted-foreground">تحليل المسار</span><h2 className="mt-1 text-lg font-bold">توزيع الفرص حسب المرحلة</h2></div><Link href="/opportunities" className="rounded-lg px-3 py-2 text-xs font-semibold text-primary hover:bg-secondary">عرض المسار <ArrowLeft className="mr-1 inline size-3.5"/></Link></div><div className="mt-7 flex h-[230px] items-end gap-3 border-b border-border pb-3 sm:gap-5">{(data?.opportunitiesByStage || []).map((s:any,i:number)=>{const max=Math.max(1,...(data?.opportunitiesByStage||[]).map((x:any)=>x.amount||x.count));const h=Math.max(12,(s.amount||s.count||0)/max*100);return <div key={s.stage} className="group flex h-full min-w-0 flex-1 flex-col justify-end text-center"><div className="relative flex-1"><div className="absolute bottom-0 right-[15%] left-[15%] rounded-t-lg bg-primary/15 transition-all group-hover:bg-primary/25" style={{height:`${h}%`}}/><div className="absolute bottom-0 right-[15%] left-[15%] rounded-t-lg bg-primary" style={{height:`${Math.max(5,h*.52)}%`,opacity:.25+i*.12}}/></div><b className="mt-3 text-xs">{Number(s.count||0).toLocaleString('ar-SA')}</b><span className="mt-1 truncate text-[10px] text-muted-foreground">{human(s.stage)}</span></div>})}{!data?.opportunitiesByStage?.length && <div className="grid w-full place-items-center text-sm text-muted-foreground">لا توجد فرص لعرضها بعد</div>}</div><div className="mt-4 flex items-center justify-between text-xs"><span className="text-muted-foreground">قيمة المسار المرجحة</span><b>{money(data?.weightedPipeline)}</b></div></div>
      <div className="relative overflow-hidden rounded-2xl bg-[#19443e] p-6 text-white"><div className="absolute -left-20 -top-20 size-56 rounded-full border border-white/10"/><div className="relative"><div className="flex items-center justify-between"><div><span className="text-xs text-white/60">إنجاز الهدف الشهري</span><b className="mt-1 block text-3xl">{Number(data?.targetProgress||0).toLocaleString('ar-SA')}٪</b></div><span className="grid size-11 place-items-center rounded-2xl bg-white/10 text-[#d5b26f]"><Zap size={19}/></span></div><div className="mt-6 h-2 overflow-hidden rounded-full bg-white/15"><div className="h-full rounded-full bg-[#d5b26f] transition-all" style={{width:`${Math.min(100,Number(data?.targetProgress||0))}%`}}/></div><div className="mt-3 flex justify-between text-[11px] text-white/60"><span>المحقق حتى الآن</span><span>الهدف {money(data?.target)}</span></div><div className="mt-8 border-t border-white/10 pt-5"><div className="mb-3 flex items-center justify-between"><b className="text-sm">أهم المتابعات</b><Link href="/tasks" className="text-xs text-[#e7c98b]">كل المتابعات <ArrowLeft className="mr-1 inline size-3"/></Link></div>{tasks.slice(0,3).map(t=><div key={t.id} className="flex items-center gap-3 border-b border-white/10 py-3 last:border-0"><span className="grid size-8 place-items-center rounded-lg bg-white/10 text-[#e5c582]"><Clock3 size={14}/></span><div className="min-w-0 flex-1"><b className="block truncate text-xs">{t.title}</b><small className="text-[10px] text-white/50">{t.clientName || 'بدون عميل'} · {dateFmt(t.dueAt)}</small></div><span className="size-1.5 rounded-full bg-[#d6b16c]"/></div>)}{!tasks.length && <p className="py-4 text-xs text-white/60">لا توجد متابعات مجدولة الآن.</p>}</div></div></div>
    </section>
    <section className="grid gap-5 xl:grid-cols-[1.35fr_.65fr]"><div className="rounded-2xl border border-card-border bg-card p-5 shadow-[var(--shadow-sm)]"><div className="flex items-center justify-between"><div><span className="text-xs text-muted-foreground">آخر المستجدات</span><h2 className="mt-1 font-bold">سجل نشاط الفريق</h2></div><Link href="/activities" className="text-xs font-semibold text-primary">عرض السجل <ArrowLeft className="mr-1 inline size-3.5"/></Link></div><div className="mt-4 divide-y divide-border">{(data?.recentActivities||[]).slice(0,4).map((a:any)=><div key={a.id} className="flex items-center gap-3 py-3"><span className="grid size-9 place-items-center rounded-xl bg-secondary text-primary"><Activity size={16}/></span><div className="min-w-0 flex-1"><b className="block truncate text-xs">{a.summary}</b><small className="text-[10px] text-muted-foreground">{a.ownerName} · {a.clientName || 'بدون عميل'}</small></div><small className="whitespace-nowrap text-[10px] text-muted-foreground">{dateFmt(a.occurredAt)}</small></div>)}{!data?.recentActivities?.length && <div className="py-8 text-center text-xs text-muted-foreground">تظهر الأنشطة المسجلة هنا</div>}</div></div><div className="rounded-2xl border border-card-border bg-card p-5 shadow-[var(--shadow-sm)]"><div className="mb-4 flex items-center gap-2"><span className="grid size-9 place-items-center rounded-xl bg-[#f4ead9] text-[#9a7137]"><HandCoins size={17}/></span><div><h3 className="text-sm font-bold">متابعة مالية</h3><small className="text-[10px] text-muted-foreground">ملخص المستحقات</small></div></div><div className="rounded-xl bg-secondary/60 p-4"><small className="text-muted-foreground">عمولات بانتظار المطابقة</small><b className="mt-1 block text-xl">{money(data?.commissionsPending)}</b></div><Link href="/commissions" className="mt-3 flex items-center justify-between rounded-xl border border-border px-4 py-3 text-xs font-semibold hover:bg-secondary">تفاصيل العمولات <ArrowLeft size={14}/></Link><Link href="/approvals" className="mt-2 flex items-center justify-between rounded-xl border border-border px-4 py-3 text-xs font-semibold hover:bg-secondary">طلبات بانتظار الموافقة <ArrowLeft size={14}/></Link></div></section>
  </div>;
}

function TablePage({ path, pageName, icon, rows, original, labels: columnLabels, keys, search, onSearch, filter, setFilter, onExport, rowAction, onAdd, deletePending }: any) {
  const filterStates = path === '/opportunities' ? ['lead','qualified','quotation','negotiation','won','lost'] : path === '/tasks' ? ['open','in_progress','completed','overdue'] : path === '/quotes' ? ['requested','pricing','ready','negotiating','accepted','declined'] : path === '/renewals' ? ['upcoming','in_progress','renewed','at_risk','lost'] : path === '/approvals' ? ['pending','approved','rejected'] : [];
  const allowAdd = ['/clients','/opportunities','/tasks','/quotes','/activities'].includes(path);
  const count = original.length;
  const headings: Record<string,string> = {
    '/clients':'كل علاقة تبدأ بملف واضح', '/opportunities':'مسار يوضح أين تقف كل صفقة', '/tasks':'المتابعة في وقتها تصنع الفارق',
    '/quotes':'عروض الأسعار ومقارنتها مع شركات التأمين','/renewals':'احتفظ بالعلاقة قبل أن تنتهي الوثيقة',
    '/commissions':'الاستحقاق المالي بكل شفافية','/approvals':'قرارات معلقة تنتظر صاحب الصلاحية',
    '/activities':'ما يحدث مع العملاء، لحظة بلحظة','/audit':'أثر موثوق لكل تغيير على السجلات',
    '/users':'الأشخاص والصلاحيات في مساحة العمل','/settings/integrations':'حالة الأنظمة المرتبطة بالعمليات',
  };
  return <div className="rise space-y-6"><div className="flex flex-col justify-between gap-4 lg:flex-row lg:items-end"><div><div className="mb-2 flex items-center gap-2 text-xs font-semibold text-primary">{icon}<span>{pageName}</span></div><h1 className="text-3xl font-bold tracking-tight">{headings[path] || pageName}</h1><p className="mt-2 text-sm text-muted-foreground">{count.toLocaleString('ar-SA')} سجل متاح ضمن نطاق صلاحيتك</p></div><div className="flex flex-wrap gap-2">{allowAdd && <button onClick={onAdd} className="inline-flex items-center gap-2 rounded-xl bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground shadow-sm transition hover:-translate-y-0.5"><Plus size={16}/>{path === '/quotes' ? 'طلب عرض سعر' : path === '/tasks' ? 'إضافة متابعة' : path === '/activities' ? 'تسجيل نشاط' : path === '/opportunities' ? 'فرصة جديدة' : 'إضافة عميل'}</button>}<button onClick={onExport} className="inline-flex items-center gap-2 rounded-xl border border-border bg-card px-4 py-2.5 text-sm font-semibold hover:bg-secondary"><ArrowDownToLine size={16}/>تصدير CSV</button></div></div>
    {path === '/opportunities' && <Pipeline rows={original}/>}
    {path === '/reports' && null}
    <div className="overflow-hidden rounded-2xl border border-card-border bg-card shadow-[var(--shadow-sm)]"><div className="flex flex-col gap-3 border-b border-border p-4 sm:flex-row sm:items-center sm:justify-between"><div className="relative min-w-0 flex-1 sm:max-w-sm"><Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground"/><input data-testid={`input-search-${path.replaceAll('/','-')}`} value={search} onChange={e=>onSearch(e.target.value)} placeholder={`ابحث في ${pageName}`} className="h-10 w-full rounded-xl border border-border bg-background pr-9 pl-3 text-sm outline-none transition focus:border-primary"/></div><div className="flex items-center gap-2"><Filter size={15} className="text-muted-foreground"/><select value={filter} onChange={e=>setFilter(e.target.value)} className="h-10 rounded-xl border border-border bg-background px-3 text-xs outline-none"><option value="all">كل الحالات</option>{filterStates.map((s:string)=><option value={s} key={s}>{human(s)}</option>)}</select><button onClick={()=>{onSearch('');setFilter('all')}} className="rounded-lg px-3 py-2 text-xs text-muted-foreground hover:bg-secondary">مسح التصفية</button></div></div>
      <div className="scrollbar-thin overflow-x-auto"><table className="w-full min-w-[820px] border-collapse text-right"><thead><tr className="bg-[#f7f6f0] text-[11px] text-muted-foreground">{columnLabels.map((title:string,i:number)=><th key={title} className="whitespace-nowrap px-4 py-3 font-semibold">{title}</th>)}{rowAction && <th className="px-4 py-3 font-semibold">إجراء</th>}</tr></thead><tbody>{rows.map((row:AnyRow,index:number)=><tr key={row.id ?? index} data-testid={`row-record-${row.id ?? index}`} className="border-t border-border/70 transition-colors hover:bg-[#f8f8f2]">{keys.map((key:string,i:number)=><td key={key} className={`max-w-[260px] px-4 py-3.5 text-[12px] ${i===0?'font-semibold text-foreground':'text-muted-foreground'}`}>{['stage','status'].includes(key) ? <StatusPill status={row[key]}/> : key === 'role' ? <span className="inline-flex rounded-lg bg-[#edf2ee] px-2.5 py-1 text-[11px] font-medium text-primary">{roleNames[row[key]] || human(row[key])}</span> : key === 'active' ? <StatusPill status={row[key] ? 'connected' : 'not_connected'}/> : <span className={key === 'premium' || key === 'grossAmount' || key === 'netAmount' ? 'font-semibold tabular-nums text-foreground' : ''}>{key === 'grossAmount' || key === 'netAmount' ? new Intl.NumberFormat('ar-SA',{style:'currency',currency:'SAR',maximumFractionDigits:0}).format(row[key]||0) : (key === 'createdAt' || key === 'requestedAt' || key === 'occurredAt' || key === 'lastSyncAt' || key === 'dueAt' || key === 'renewalDate' || key === 'lastContactAt') ? dateFmt(row[key]) : key === 'premium' || key === 'amount' ? new Intl.NumberFormat('ar-SA',{style:'currency',currency:'SAR',maximumFractionDigits:0}).format(row[key]||0) : key === 'probability' ? `${Number(row[key]||0).toLocaleString('ar-SA')}٪` : cellVal(row[key])}</span>}</td>)}{rowAction && <td className="whitespace-nowrap px-4 py-3.5">{rowAction(row)}</td>}</tr>)}
      </tbody></table>{!rows.length && <div className="flex flex-col items-center px-6 py-14 text-center"><span className="grid size-12 place-items-center rounded-2xl bg-secondary text-primary"><icon.type size={21}/></span><h3 className="mt-4 font-bold">{original.length ? 'لا توجد نتائج مطابقة' : 'لا توجد سجلات بعد'}</h3><p className="mt-1 max-w-sm text-xs leading-6 text-muted-foreground">{original.length ? 'غيّر كلمة البحث أو وسّع نطاق التصفية.' : 'ستظهر السجلات هنا عند توفر بيانات في مساحة العمل.'}</p>{allowAdd && !original.length && <button onClick={onAdd} className="mt-4 rounded-lg bg-primary px-4 py-2 text-xs font-semibold text-primary-foreground"><Plus size={14} className="ml-1 inline"/> أضف أول سجل</button>}</div>}</div><div className="flex items-center justify-between border-t border-border px-4 py-3 text-[11px] text-muted-foreground"><span>عرض {rows.length.toLocaleString('ar-SA')} من {count.toLocaleString('ar-SA')} سجل</span><span>تظهر السجلات بحسب صلاحيات المستخدم</span></div></div>
    {deletePending && <div className="text-xs text-muted-foreground">جارٍ حذف سجل العميل…</div>}
  </div>;
}
function Pipeline({ rows }: { rows: AnyRow[] }) {
  const qc = useQueryClient();
  const update = API.useUpdateOpportunity();
  const stages = ['lead','qualified','quotation','negotiation','won','lost'] as const;
  type Stage = (typeof stages)[number];
  const change = (id:number, stage:Stage) => update.mutate({ id, data: { stage } }, { onSuccess: () => { qc.invalidateQueries({ queryKey: API.getListOpportunitiesQueryKey() }); qc.invalidateQueries({ queryKey: API.getGetDashboardQueryKey() }); } });
  return <section className="overflow-x-auto pb-1"><div className="flex min-w-[900px] gap-3">{stages.map((stage,index)=>{const group=rows.filter(row=>row.stage===stage);return <div key={stage} onDragOver={e=>e.preventDefault()} onDrop={e=>{e.preventDefault();const id=Number(e.dataTransfer.getData('text/plain'));if(id)change(id,stage)}} className="min-h-[154px] flex-1 rounded-2xl border border-border bg-[#eeeee6]/70 p-3"><div className="mb-3 flex items-center justify-between"><div className="flex items-center gap-2"><span className={`size-2 rounded-full ${['bg-slate-400','bg-[#62897d]','bg-[#c09b59]','bg-[#b97e55]','bg-[#4d866d]','bg-rose-500'][index]}`}/><b className="text-xs">{human(stage)}</b></div><span className="rounded-md bg-card px-2 py-1 text-[10px] text-muted-foreground">{group.length}</span></div><div className="space-y-2">{group.slice(0,4).map(row=><article key={row.id} draggable onDragStart={e=>e.dataTransfer.setData('text/plain',String(row.id))} className="cursor-grab rounded-xl border border-border/80 bg-card p-3 shadow-sm active:cursor-grabbing"><div className="flex items-start justify-between gap-2"><b className="text-xs leading-5">{row.title}</b><button title="نقل للمرحلة التالية" onClick={()=>change(row.id,stages[Math.min(stages.indexOf(stage)+1,stages.length-1)])} className="rounded p-1 text-muted-foreground hover:bg-secondary"><ArrowLeft size={13}/></button></div><small className="mt-1 block text-[10px] text-muted-foreground">{row.clientName} · {row.ownerName}</small><div className="mt-3 flex items-center justify-between"><b className="text-xs">{money(row.premium)}</b><span className="text-[10px] text-muted-foreground">{Number(row.probability||0).toLocaleString('ar-SA')}٪</span></div></article>)}</div></div>})}</div><p className="mt-2 text-[10px] text-muted-foreground">اسحب البطاقة إلى مرحلة جديدة، أو استخدم سهم النقل. يتم حفظ التغيير مباشرة.</p></section>;
}
function Reports({ data }: { data: any }) {
  const tiles = [['إجمالي العملاء',data?.totalClients,Users],['الفرص المفتوحة',data?.openOpportunities,Gauge],['قيمة المسار المرجحة',money(data?.weightedPipeline),HandCoins],['إيرادات الشهر',money(data?.revenueThisMonth),Zap],['التجديدات المستحقة',data?.renewalsDue,Clock3],['عمولات قيد الصرف',money(data?.commissionsPending),FileCheck2]] as any[];
  const exportCsv = () => {
    const rows = [['المؤشر','القيمة'], ...tiles.map(([title,value]) => [title, value ?? ''])];
    const csv = rows.map(row => row.map(value => `"${String(value).replaceAll('"','""')}"`).join(',')).join('\n');
    const url = URL.createObjectURL(new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8' }));
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = 'insurance-sales-report.csv';
    anchor.click();
    URL.revokeObjectURL(url);
  };
  return <div className="rise space-y-6"><div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end"><div><div className="mb-2 flex items-center gap-2 text-xs font-semibold text-primary"><BriefcaseBusiness size={18}/>مركز الرؤية</div><h1 className="text-3xl font-bold">التقارير والتحليلات</h1><p className="mt-2 text-sm text-muted-foreground">مؤشرات محسوبة مباشرة من السجلات المتاحة ضمن نطاق صلاحيتك.</p></div><button onClick={exportCsv} className="inline-flex items-center gap-2 self-start rounded-xl border border-border bg-card px-4 py-2.5 text-sm font-semibold hover:bg-secondary"><ArrowDownToLine size={16}/>تصدير التقرير</button></div><div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">{tiles.map(([title,value,Icon])=><article key={title} className="rounded-2xl border border-card-border bg-card p-5 shadow-[var(--shadow-sm)]"><div className="flex justify-between"><span className="text-sm text-muted-foreground">{title}</span><span className="grid size-9 place-items-center rounded-xl bg-secondary text-primary"><Icon size={17}/></span></div><b className="mt-5 block text-2xl">{value === undefined ? '—' : typeof value === 'number' ? value.toLocaleString('ar-SA') : value}</b><small className="mt-1 block text-xs text-muted-foreground">حسب البيانات المسجلة حالياً</small></article>)}</div><div className="rounded-2xl border border-card-border bg-card p-6"><div className="flex items-center gap-3"><span className="grid size-10 place-items-center rounded-xl bg-[#f4ead9] text-[#9a7137]"><SlidersHorizontal size={18}/></span><div><h2 className="font-bold">نطاق التقرير</h2><p className="text-xs text-muted-foreground">تتغير المؤشرات وفق دور المستخدم ونطاق الفرع أو الفريق أو ملكية السجل.</p></div></div><p className="mt-5 rounded-xl bg-secondary/60 p-4 text-sm leading-7 text-muted-foreground">معدلات التحويل والاحتفاظ والالتزام بالمواعيد ستظهر بعد استيراد البيانات التاريخية وتحديد الأهداف وفترات القياس.</p></div></div>;
}

function EntryModal({ kind, form, setForm, close, submit, step, busy, clients }: any) {
  const title = kind === 'client' ? (form.id ? 'تحديث ملف العميل' : 'إضافة عميل جديد') : kind === 'opportunity' ? 'إنشاء فرصة بيعية' : kind === 'task' ? 'إضافة متابعة جديدة' : kind === 'activity' ? 'تسجيل نشاط' : 'طلب عرض سعر';
  const fields: Record<string, any[]> = {
    client: [['name','اسم العميل'],['companyName','اسم المنشأة'],['phone','رقم الجوال'],['email','البريد الإلكتروني'],['premium','القسط السنوي']],
    opportunity: [['title','عنوان الفرصة'],['clientName','اسم العميل'],['product','نوع التأمين'],['premium','القسط المتوقع'],['probability','احتمالية الفوز %'],['closeDate','تاريخ الإغلاق المتوقع']],
    task: [['title','عنوان المتابعة'],['clientName','اسم العميل'],['dueAt','موعد المتابعة']],
    activity: [['summary','ملخص النشاط'],['clientName','اسم العميل']],
    quote: step === 1 ? [['clientName','اسم العميل'],['product','نوع التأمين']] : step === 2 ? [['insurer','شركة التأمين'],['premium','القسط المقترح']] : [['expiresAt','تاريخ انتهاء العرض']],
  };
  const updateField = (key:string,value:string) => setForm((prev:any)=>({...prev,[key]:value}));
  return <div className="fixed inset-0 z-[70] flex items-end justify-center bg-foreground/40 p-0 backdrop-blur-[2px] sm:items-center sm:p-5" onMouseDown={e=>{if(e.target===e.currentTarget)close()}}><form onSubmit={submit} className="max-h-[92dvh] w-full max-w-xl overflow-y-auto rounded-t-3xl border border-border bg-card p-5 shadow-2xl sm:rounded-3xl sm:p-7"><div className="flex items-start justify-between"><div><div className="mb-2 text-xs font-semibold text-primary">{kind==='quote' ? `الخطوة ${step} من ٣` : 'بيانات مساحة العمل'}</div><h2 className="text-xl font-bold">{title}</h2><p className="mt-1 text-xs text-muted-foreground">{kind==='quote' ? 'أدخل التفاصيل على مراحل، ثم أرسل طلب التسعير.' : 'ستحفظ التغييرات مباشرة في سجل العمليات.'}</p></div><button type="button" onClick={close} className="rounded-lg p-2 text-muted-foreground hover:bg-secondary"><X size={18}/></button></div>{kind==='quote' && <div className="mt-5 flex gap-2">{[1,2,3].map(x=><span key={x} className={`h-1.5 flex-1 rounded-full ${x<=step?'bg-primary':'bg-secondary'}`}/>)}</div>}<div className="mt-6 grid gap-4 sm:grid-cols-2">{fields[kind].map(([key,label]:string[])=>{const type=key==='premium'||key==='probability'?'number':key.toLowerCase().includes('date')||key==='dueAt'||key==='expiresAt'?'date':key==='email'?'email':'text';return <label key={key} className="flex flex-col gap-2 text-xs font-semibold text-foreground">{label}<input required={key==='name'||key==='title'||key==='clientName'||key==='summary'} type={type} min={type==='number'?0:undefined} value={form[key] || ''} onChange={e=>updateField(key,e.target.value)} placeholder={label} className="h-11 rounded-xl border border-border bg-background px-3 text-sm font-normal outline-none transition focus:border-primary"/></label>})}
      {kind==='client' && <label className="flex flex-col gap-2 text-xs font-semibold">نوع العميل<select value={form.clientType||'company'} onChange={e=>updateField('clientType',e.target.value)} className="h-11 rounded-xl border border-border bg-background px-3 text-sm"><option value="company">شركة</option><option value="individual">فرد</option></select></label>}
      {kind==='client' && <label className="flex flex-col gap-2 text-xs font-semibold">مصدر العميل<input value={form.source||''} onChange={e=>updateField('source',e.target.value)} placeholder="إحالة، حملة..." className="h-11 rounded-xl border border-border bg-background px-3 text-sm font-normal"/></label>}
      {kind==='opportunity' && <label className="flex flex-col gap-2 text-xs font-semibold">المرحلة<select value={form.stage||'lead'} onChange={e=>updateField('stage',e.target.value)} className="h-11 rounded-xl border border-border bg-background px-3 text-sm">{['lead','qualified','quotation','negotiation'].map(s=><option key={s} value={s}>{human(s)}</option>)}</select></label>}
      {kind==='task' && <label className="flex flex-col gap-2 text-xs font-semibold">نوع المتابعة<select value={form.taskType||'follow_up'} onChange={e=>updateField('taskType',e.target.value)} className="h-11 rounded-xl border border-border bg-background px-3 text-sm">{['call','meeting','follow_up','document','other'].map(s=><option key={s} value={s}>{human(s)}</option>)}</select></label>}
      {kind==='task' && <label className="flex flex-col gap-2 text-xs font-semibold">الأولوية<select value={form.priority||'medium'} onChange={e=>updateField('priority',e.target.value)} className="h-11 rounded-xl border border-border bg-background px-3 text-sm">{['high','medium','low'].map(s=><option key={s} value={s}>{human(s)}</option>)}</select></label>}
      {kind==='activity' && <label className="flex flex-col gap-2 text-xs font-semibold">نوع النشاط<select value={form.activityType||'note'} onChange={e=>updateField('activityType',e.target.value)} className="h-11 rounded-xl border border-border bg-background px-3 text-sm">{['call','meeting','email','note','stage_change'].map(s=><option key={s} value={s}>{human(s)}</option>)}</select></label>}
      {kind==='quote' && step===1 && clients.length>0 && <label className="flex flex-col gap-2 text-xs font-semibold">ربط بملف عميل<select value={form.clientId||''} onChange={e=>{const selected=clients.find((c:any)=>String(c.id)===e.target.value);setForm((prev:any)=>({...prev,clientId:e.target.value,clientName:selected?.name||prev.clientName}))}} className="h-11 rounded-xl border border-border bg-background px-3 text-sm"><option value="">اختيار من العملاء</option>{clients.map((c:any)=><option key={c.id} value={c.id}>{c.name}</option>)}</select></label>}
    </div><div className="mt-7 flex gap-2 border-t border-border pt-5"><button disabled={busy} className="inline-flex flex-1 items-center justify-center gap-2 rounded-xl bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground disabled:opacity-60">{busy ? 'جارٍ الحفظ…' : kind==='quote'&&step<3 ? <>التالي <ArrowLeft size={15}/></> : kind==='quote' ? 'إرسال طلب التسعير' : form.id ? 'حفظ التغييرات' : 'حفظ السجل'}</button>{kind==='quote'&&step>1&&<button type="button" onClick={()=>{}} className="rounded-xl border border-border px-4 py-3 text-sm" disabled>الخطوة {step}</button>}<button type="button" onClick={close} className="rounded-xl border border-border px-5 py-3 text-sm hover:bg-secondary">إلغاء</button></div></form></div>;
}

function HomeRoute() {
  return <><Show when="signed-out"><Landing/></Show><Show when="signed-in"><Workspace/></Show></>;
}
function AuthenticatedRoute({ children }: { children: ReactNode }) {
  return <><Show when="signed-in">{children}</Show><Show when="signed-out"><Landing/></Show></>;
}
function Router() {
  const [, setLocation] = useLocation();
  return <ErrorBoundary resetKey={window.location.pathname}><Switch>
    <Route path="/" component={HomeRoute}/>
    <Route path="/sign-in/*?" component={SignInPage}/>
    <Route path="/sign-up/*?" component={SignUpPage}/>
    {modules.slice(1).map(m=><Route key={m.href} path={m.href}><AuthenticatedRoute><Workspace/></AuthenticatedRoute></Route>)}
    <Route component={NotFound}/>
  </Switch></ErrorBoundary>;
}
function ClerkRoutes() {
  const [, setLocation] = useLocation();
  return <ClerkProvider publishableKey={clerkPubKey} proxyUrl={clerkProxyUrl} appearance={appearance} signInUrl={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`}
    localization={{ signIn: { start: { title: 'مرحباً بعودتك', subtitle: 'سجّل الدخول للوصول إلى مساحة عملك' } }, signUp: { start: { title: 'أنشئ حسابك', subtitle: 'ابدأ إدارة علاقاتك البيعية بوضوح' } } }}
    routerPush={to=>setLocation(stripBase(to))} routerReplace={to=>setLocation(stripBase(to),{replace:true})}>
    <ClerkQueryClientCacheInvalidator/><Router/>
  </ClerkProvider>;
}
function ClerkQueryClientCacheInvalidator() {
  const { addListener } = useClerk();
  const client = useQueryClient();
  const previousUserId = useRef<string | null | undefined>(undefined);
  useEffect(() => {
    const unsubscribe = addListener(({ user }) => {
      const userId = user?.id ?? null;
      if (previousUserId.current !== undefined && previousUserId.current !== userId) client.clear();
      previousUserId.current = userId;
    });
    return unsubscribe;
  }, [addListener, client]);
  return null;
}
function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={basePath}><ClerkRoutes/></WouterRouter><Toaster/></TooltipProvider></QueryClientProvider>;
}

export default App;
