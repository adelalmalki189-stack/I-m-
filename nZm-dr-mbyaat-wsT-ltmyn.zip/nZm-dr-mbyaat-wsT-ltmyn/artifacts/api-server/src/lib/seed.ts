import { db, businessIntegrationsTable } from "@workspace/db";

export async function seedDefaultIntegrations(): Promise<void> {
  const [existing] = await db
    .select({ id: businessIntegrationsTable.id })
    .from(businessIntegrationsTable)
    .limit(1);
  if (existing) return;

  await db.insert(businessIntegrationsTable).values([
    {
      name: "إصدار الوثائق",
      purpose: "إرسال طلبات الإصدار واستلام حالة الوثيقة من نظام شركة التأمين",
      status: "not_connected",
    },
    {
      name: "إدارة المطالبات",
      purpose: "متابعة حالة المطالبة وربطها بملف العميل",
      status: "not_connected",
    },
    {
      name: "المحاسبة",
      purpose: "مطابقة الأقساط والعمولات وحالات التحصيل",
      status: "not_connected",
    },
  ]);
}
