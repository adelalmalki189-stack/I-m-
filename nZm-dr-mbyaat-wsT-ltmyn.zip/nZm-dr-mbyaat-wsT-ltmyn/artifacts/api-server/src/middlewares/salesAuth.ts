import { getAuth } from "@clerk/express";
import type { Request, RequestHandler } from "express";
import { eq, sql } from "drizzle-orm";
import { db, usersTable } from "@workspace/db";

export type SalesRole =
  | "system_admin"
  | "sales_manager"
  | "team_leader"
  | "sales_executive"
  | "business_development"
  | "pricing_officer"
  | "finance"
  | "top_management";

export type SalesUser = typeof usersTable.$inferSelect;
export type ScopedRecord = {
  ownerId?: string | null;
  branch?: string | null;
  team?: string | null;
};

declare global {
  namespace Express {
    interface Request {
      salesUser?: SalesUser;
    }
  }
}

export const requireSalesUser: RequestHandler = async (req, res, next) => {
  const auth = getAuth(req);
  const userId = auth?.userId;
  if (!userId) {
    res.status(401).json({ error: "Authentication required" });
    return;
  }

  const user = await db.transaction(async (tx) => {
    // Serialize first-account bootstrap so two simultaneous sign-ups cannot
    // both receive the initial administrator role.
    await tx.execute(sql`SELECT pg_advisory_xact_lock(8472551)`);
    const [existing] = await tx
      .select()
      .from(usersTable)
      .where(eq(usersTable.id, userId))
      .limit(1);
    if (existing) return existing;

    const [anyUser] = await tx.select({ id: usersTable.id }).from(usersTable).limit(1);
    const [created] = await tx
      .insert(usersTable)
      .values({
        id: userId,
        name: "عضو جديد",
        email: "غير متاح",
        role: anyUser ? "sales_executive" : "system_admin",
      })
      .returning();
    return created;
  });

  req.salesUser = user;
  next();
};

export function salesUser(req: Request): SalesUser {
  if (!req.salesUser) throw new Error("Authenticated sales user is missing");
  return req.salesUser;
}

export function canReadScope(user: SalesUser, row: ScopedRecord): boolean {
  if (user.role === "system_admin") return true;
  if (user.role === "sales_manager") return row.branch === user.branch;
  if (user.role === "team_leader") {
    return row.branch === user.branch && row.team === user.team;
  }
  if (user.role === "top_management") return false;
  if (user.role === "pricing_officer" || user.role === "finance") return false;
  return row.ownerId === user.id;
}

export function canReadContacts(user: SalesUser): boolean {
  return [
    "system_admin",
    "sales_manager",
    "team_leader",
    "sales_executive",
    "business_development",
  ].includes(user.role);
}

export function canReadFinancialDetail(
  user: SalesUser,
  row?: ScopedRecord,
): boolean {
  if (["system_admin", "sales_manager", "team_leader", "finance"].includes(user.role)) {
    return true;
  }
  return (
    ["sales_executive", "business_development"].includes(user.role) &&
    row?.ownerId === user.id
  );
}

export function canViewCommissionDetail(user: SalesUser): boolean {
  return user.role === "system_admin" || user.role === "finance";
}

export function canReassignOwner(
  user: SalesUser,
  destination: Pick<ScopedRecord, "branch" | "team">,
): boolean {
  if (user.role === "system_admin") return true;
  if (user.role === "sales_manager") return destination.branch === user.branch;
  if (user.role === "team_leader") {
    return (
      destination.branch === user.branch &&
      destination.team === user.team
    );
  }
  return false;
}

export function canManageApprovals(user: SalesUser): boolean {
  return ["system_admin", "sales_manager", "team_leader"].includes(user.role);
}

export function canManageRoles(user: SalesUser): boolean {
  return user.role === "system_admin";
}

export function canReadTeamActivity(user: SalesUser): boolean {
  return ["system_admin", "sales_manager", "team_leader"].includes(user.role);
}

