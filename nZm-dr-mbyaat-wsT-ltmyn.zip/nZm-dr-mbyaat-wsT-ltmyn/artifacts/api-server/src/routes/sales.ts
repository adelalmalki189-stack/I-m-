import { Router, type IRouter, type Request, type Response } from "express";
import { desc, eq } from "drizzle-orm";
import {
  Activity,
  Client,
  CreateActivityBody,
  CreateActivityResponse,
  CreateClientBody,
  CreateClientResponse,
  CreateOpportunityBody,
  CreateOpportunityResponse,
  CreateQuoteBody,
  CreateQuoteResponse,
  CreateTaskBody,
  CreateTaskResponse,
  DashboardSummary,
  GetClientParams,
  GetClientResponse,
  GetDashboardResponse,
  GetReportsResponse,
  ListActivitiesResponse,
  ListApprovalsResponse,
  ListAuditEntriesResponse,
  ListClientsQueryParams,
  ListClientsResponse,
  ListCommissionsResponse,
  ListIntegrationsResponse,
  ListOpportunitiesQueryParams,
  ListOpportunitiesResponse,
  ListQuotesResponse,
  ListRenewalsResponse,
  ListTasksQueryParams,
  ListTasksResponse,
  ListUsersResponse,
  ReportSummary,
  Task,
  UpdateApprovalBody,
  UpdateApprovalParams,
  UpdateApprovalResponse,
  UpdateClientBody,
  UpdateClientParams,
  UpdateClientResponse,
  UpdateOpportunityBody,
  UpdateOpportunityParams,
  UpdateOpportunityResponse,
  UpdateQuoteBody,
  UpdateQuoteParams,
  UpdateQuoteResponse,
  UpdateRenewalBody,
  UpdateRenewalParams,
  UpdateRenewalResponse,
  UpdateTaskBody,
  UpdateTaskParams,
  UpdateTaskResponse,
  UpdateUserRoleBody,
  UpdateUserRoleParams,
  UpdateUserRoleResponse,
} from "@workspace/api-zod";
import {
  activitiesTable,
  approvalsTable,
  auditEntriesTable,
  businessIntegrationsTable,
  clientsTable,
  commissionsTable,
  opportunitiesTable,
  quotesTable,
  renewalsTable,
  targetsTable,
  tasksTable,
  usersTable,
  db,
} from "@workspace/db";
import {
  canManageApprovals,
  canManageRoles,
  canReadContacts,
  canReadFinancialDetail,
  canReadScope,
  canReadTeamActivity,
  canReassignOwner,
  canViewCommissionDetail,
  requireSalesUser,
  salesUser,
  type SalesUser,
  type ScopedRecord,
} from "../middlewares/salesAuth";

const router: IRouter = Router();
router.use(requireSalesUser);

const roleValues = [
  "system_admin",
  "sales_manager",
  "team_leader",
  "sales_executive",
  "business_development",
  "pricing_officer",
  "finance",
  "top_management",
] as const;

function invalid(res: Response, error: string) {
  res.status(400).json({ error });
}

function filterScope<T extends ScopedRecord>(user: SalesUser, rows: T[]): T[] {
  return rows.filter((row) => canReadScope(user, row));
}

function contactSafe<T extends { email?: string | null; phone?: string | null }>(
  user: SalesUser,
  row: T,
): T {
  return canReadContacts(user) ? row : { ...row, email: null, phone: null };
}

function clientSafe(user: SalesUser, row: typeof clientsTable.$inferSelect): Client {
  const permitted = canReadFinancialDetail(user, row);
  return {
    ...contactSafe(user, row),
    premium: permitted ? row.premium : 0,
  } as Client;
}

function recordScope(
  user: SalesUser,
  row: Pick<ScopedRecord, "branch" | "team" | "ownerId">,
): boolean {
  return canReadScope(user, row);
}

function newOwnerFields(
  user: SalesUser,
  data: { ownerId?: string; branch?: string; team?: string },
  current: ScopedRecord & { ownerId: string },
) {
  if (!data.ownerId || data.ownerId === current.ownerId) return {};
  if (!canReassignOwner(user, current)) {
    return { error: "تغيير مالك السجل يتطلب تفويضاً إدارياً" } as const;
  }
  return { ownerId: data.ownerId };
}

async function ownerDisplayName(
  currentUser: SalesUser,
  ownerId: string,
): Promise<string | null> {
  const [owner] = await db
    .select({
      name: usersTable.name,
      active: usersTable.active,
      branch: usersTable.branch,
      team: usersTable.team,
    })
    .from(usersTable)
    .where(eq(usersTable.id, ownerId))
    .limit(1);
  return owner?.active && canReassignOwner(currentUser, owner) ? owner.name : null;
}

async function addAudit(req: Request, action: string, entityType: string, entityId: number) {
  const user = salesUser(req);
  await db.insert(auditEntriesTable).values({
    actorId: user.id,
    actor: user.name,
    action,
    entityType,
    entityId,
  });
}

router.get("/dashboard", async (req, res): Promise<void> => {
  const user = salesUser(req);
  const [clients, opportunities, tasks, activities, commissions, renewals, targets] =
    await Promise.all([
      db.select().from(clientsTable),
      db.select().from(opportunitiesTable),
      db.select().from(tasksTable),
      db.select().from(activitiesTable).orderBy(desc(activitiesTable.occurredAt)),
      db.select().from(commissionsTable),
      db.select().from(renewalsTable),
      db.select().from(targetsTable),
    ]);
  const visibleClients = filterScope(user, clients);
  const visibleOpportunities = filterScope(user, opportunities);
  const visibleTasks = filterScope(user, tasks);
  const visibleActivities = activities.filter((row) =>
    canReadTeamActivity(user)
      ? recordScope(user, row)
      : row.ownerId === user.id,
  );
  const commissionRows =
    user.role === "system_admin" || user.role === "finance"
      ? commissions
      : commissions.filter((row) => row.employeeId === user.id);
  const scopedRenewals = filterScope(user, renewals);
  const scopedTargets = targets.filter((row) => {
    if (user.role === "system_admin") return true;
    if (user.role === "sales_manager") {
      return row.employeeId === user.id || visibleOpportunities.some((opp) => opp.ownerId === row.employeeId);
    }
    if (user.role === "team_leader") {
      return visibleOpportunities.some((opp) => opp.ownerId === row.employeeId);
    }
    return row.employeeId === user.id;
  });
  const open = visibleOpportunities.filter(
    (item) => !["won", "lost"].includes(item.stage),
  );
  const stageNames = ["lead", "qualified", "quotation", "negotiation", "won", "lost"];
  const month = new Date().toISOString().slice(0, 7);
  const pendingCommissionTotal = commissionRows
    .filter((item) => item.status === "pending")
    .reduce((sum, item) => sum + item.grossAmount, 0);
  const today = new Date().toISOString().slice(0, 10);
  const nextMonth = new Date(Date.now() + 30 * 86400000).toISOString().slice(0, 10);
  const value: DashboardSummary = {
    totalClients: visibleClients.length,
    openOpportunities: open.length,
    weightedPipeline: open.reduce(
      (sum, item) => sum + item.premium * (item.probability / 100),
      0,
    ),
    revenueThisMonth: commissionRows
      .filter((item) => item.period === month)
      .reduce((sum, item) => sum + item.grossAmount, 0),
    target: scopedTargets.reduce((sum, item) => sum + item.premiumTarget, 0),
    targetProgress: 0,
    renewalsDue: scopedRenewals.filter(
      (item) => item.renewalDate >= today && item.renewalDate <= nextMonth,
    ).length,
    commissionsPending: canReadFinancialDetail(user) || canViewCommissionDetail(user)
      ? pendingCommissionTotal
      : 0,
    opportunitiesByStage: stageNames.map((stage) => {
      const stageRows = visibleOpportunities.filter((item) => item.stage === stage);
      return {
        stage,
        count: stageRows.length,
        amount: stageRows.reduce((sum, item) => sum + item.premium, 0),
      };
    }),
    recentActivities: visibleActivities.slice(0, 6) as Activity[],
    dueTasks: visibleTasks
      .filter((item) => item.status !== "completed")
      .sort((a, b) => a.dueAt.getTime() - b.dueAt.getTime())
      .slice(0, 5) as Task[],
  };
  value.targetProgress =
    value.target > 0 ? Math.min(100, (value.revenueThisMonth / value.target) * 100) : 0;
  res.json(GetDashboardResponse.parse(value));
});

router.get("/clients", async (req, res): Promise<void> => {
  const user = salesUser(req);
  const query = ListClientsQueryParams.safeParse(req.query);
  if (!query.success) {
    invalid(res, query.error.message);
    return;
  }
  let rows = filterScope(user, await db.select().from(clientsTable));
  if (query.data.clientType) {
    rows = rows.filter((row) => row.clientType === query.data.clientType);
  }
  if (query.data.search) {
    const search = query.data.search.toLocaleLowerCase();
    rows = rows.filter((row) =>
      [row.name, row.companyName, row.phone, row.email]
        .filter(Boolean)
        .some((value) => value!.toLocaleLowerCase().includes(search)),
    );
  }
  res.json(ListClientsResponse.parse(rows.map((row) => clientSafe(user, row))));
});

router.post("/clients", async (req, res): Promise<void> => {
  const parsed = CreateClientBody.safeParse(req.body);
  if (!parsed.success) {
    invalid(res, parsed.error.message);
    return;
  }
  const user = salesUser(req);
  const [row] = await db
    .insert(clientsTable)
    .values({
      ...parsed.data,
      ownerId: user.id,
      ownerName: user.name,
      branch: user.role === "system_admin" ? parsed.data.branch : user.branch,
      team: user.role === "system_admin" ? parsed.data.team : user.team,
    })
    .returning();
  await addAudit(req, "create", "client", row.id);
  res.status(201).json(CreateClientResponse.parse(clientSafe(user, row)));
});

router.get("/clients/:id", async (req, res): Promise<void> => {
  const params = GetClientParams.safeParse(req.params);
  if (!params.success) {
    invalid(res, params.error.message);
    return;
  }
  const user = salesUser(req);
  const [row] = await db.select().from(clientsTable).where(eq(clientsTable.id, params.data.id));
  if (!row || !canReadScope(user, row)) {
    res.status(404).json({ error: "Client not found" });
    return;
  }
  res.json(GetClientResponse.parse(clientSafe(user, row)));
});

router.patch("/clients/:id", async (req, res): Promise<void> => {
  const params = UpdateClientParams.safeParse(req.params);
  const parsed = UpdateClientBody.safeParse(req.body);
  if (!params.success) {
    invalid(res, params.error.message);
    return;
  }
  if (!parsed.success) {
    invalid(res, parsed.error.message);
    return;
  }
  const user = salesUser(req);
  const [existing] = await db.select().from(clientsTable).where(eq(clientsTable.id, params.data.id));
  if (!existing || !canReadScope(user, existing)) {
    res.status(404).json({ error: "Client not found" });
    return;
  }
  if (
    user.role !== "system_admin" &&
    ((parsed.data.branch && parsed.data.branch !== existing.branch) ||
      (parsed.data.team && parsed.data.team !== existing.team))
  ) {
    res.status(403).json({ error: "لا تملك صلاحية نقل السجل بين الفروع أو الفرق" });
    return;
  }
  const owner = newOwnerFields(user, parsed.data, existing);
  if ("error" in owner) {
    res.status(403).json({ error: owner.error });
    return;
  }
  let ownerName: string | undefined;
  if (owner.ownerId) {
    ownerName = await ownerDisplayName(user, owner.ownerId) ?? undefined;
    if (!ownerName) {
      res.status(400).json({ error: "المستخدم المحدد غير نشط أو غير موجود" });
      return;
    }
  }
  const { ownerId: _ownerId, ownerName: _ownerName, ...safeData } = parsed.data;
  const [row] = await db
    .update(clientsTable)
    .set({ ...safeData, ...owner, ...(ownerName ? { ownerName } : {}) })
    .where(eq(clientsTable.id, params.data.id))
    .returning();
  await addAudit(req, "update", "client", row.id);
  res.json(UpdateClientResponse.parse(clientSafe(user, row)));
});

router.delete("/clients/:id", async (req, res): Promise<void> => {
  const params = GetClientParams.safeParse(req.params);
  if (!params.success) {
    invalid(res, params.error.message);
    return;
  }
  const user = salesUser(req);
  const [existing] = await db.select().from(clientsTable).where(eq(clientsTable.id, params.data.id));
  if (!existing || !canReadScope(user, existing)) {
    res.status(404).json({ error: "Client not found" });
    return;
  }
  if (!["system_admin", "sales_manager"].includes(user.role)) {
    res.status(403).json({ error: "حذف العميل يتطلب صلاحية إدارية" });
    return;
  }
  const [row] = await db.delete(clientsTable).where(eq(clientsTable.id, params.data.id)).returning();
  await addAudit(req, "delete", "client", row.id);
  res.sendStatus(204);
});

router.get("/opportunities", async (req, res): Promise<void> => {
  const user = salesUser(req);
  const query = ListOpportunitiesQueryParams.safeParse(req.query);
  if (!query.success) {
    invalid(res, query.error.message);
    return;
  }
  let rows = filterScope(user, await db.select().from(opportunitiesTable));
  if (query.data.stage) rows = rows.filter((row) => row.stage === query.data.stage);
  if (query.data.search) {
    const search = query.data.search.toLocaleLowerCase();
    rows = rows.filter((row) =>
      `${row.title} ${row.clientName} ${row.product}`.toLocaleLowerCase().includes(search),
    );
  }
  res.json(ListOpportunitiesResponse.parse(rows));
});

router.post("/opportunities", async (req, res): Promise<void> => {
  const parsed = CreateOpportunityBody.safeParse(req.body);
  if (!parsed.success) {
    invalid(res, parsed.error.message);
    return;
  }
  const user = salesUser(req);
  const [row] = await db
    .insert(opportunitiesTable)
    .values({
      ...parsed.data,
      ownerId: user.id,
      ownerName: user.name,
      branch: user.role === "system_admin" ? parsed.data.branch : user.branch,
      team: user.role === "system_admin" ? parsed.data.team : user.team,
      closeDate: parsed.data.closeDate
        ? parsed.data.closeDate.toISOString().slice(0, 10)
        : null,
    })
    .returning();
  await addAudit(req, "create", "opportunity", row.id);
  res.status(201).json(CreateOpportunityResponse.parse(row));
});

router.patch("/opportunities/:id", async (req, res): Promise<void> => {
  const params = UpdateOpportunityParams.safeParse(req.params);
  const parsed = UpdateOpportunityBody.safeParse(req.body);
  if (!params.success) {
    invalid(res, params.error.message);
    return;
  }
  if (!parsed.success) {
    invalid(res, parsed.error.message);
    return;
  }
  const user = salesUser(req);
  const [existing] = await db.select().from(opportunitiesTable).where(eq(opportunitiesTable.id, params.data.id));
  if (!existing || !canReadScope(user, existing)) {
    res.status(404).json({ error: "Opportunity not found" });
    return;
  }
  if (
    user.role !== "system_admin" &&
    ((parsed.data.branch && parsed.data.branch !== existing.branch) ||
      (parsed.data.team && parsed.data.team !== existing.team))
  ) {
    res.status(403).json({ error: "لا تملك صلاحية نقل السجل بين الفروع أو الفرق" });
    return;
  }
  const owner = newOwnerFields(user, parsed.data, existing);
  if ("error" in owner) {
    res.status(403).json({ error: owner.error });
    return;
  }
  let ownerName: string | undefined;
  if (owner.ownerId) {
    ownerName = await ownerDisplayName(user, owner.ownerId) ?? undefined;
    if (!ownerName) {
      res.status(400).json({ error: "المستخدم المحدد غير نشط أو غير موجود" });
      return;
    }
  }
  const {
    ownerId: _ownerId,
    ownerName: _ownerName,
    closeDate,
    ...safeData
  } = parsed.data;
  const [row] = await db
    .update(opportunitiesTable)
    .set({
      ...safeData,
      ...owner,
      ...(ownerName ? { ownerName } : {}),
      ...(closeDate !== undefined
        ? { closeDate: closeDate ? closeDate.toISOString().slice(0, 10) : null }
        : {}),
    })
    .where(eq(opportunitiesTable.id, params.data.id))
    .returning();
  await addAudit(req, "update", "opportunity", row.id);
  res.json(UpdateOpportunityResponse.parse(row));
});

router.get("/tasks", async (req, res): Promise<void> => {
  const user = salesUser(req);
  const query = ListTasksQueryParams.safeParse(req.query);
  if (!query.success) {
    invalid(res, query.error.message);
    return;
  }
  let rows = filterScope(user, await db.select().from(tasksTable));
  if (query.data.status) rows = rows.filter((row) => row.status === query.data.status);
  rows.sort((a, b) => a.dueAt.getTime() - b.dueAt.getTime());
  res.json(ListTasksResponse.parse(rows));
});

router.post("/tasks", async (req, res): Promise<void> => {
  const parsed = CreateTaskBody.safeParse(req.body);
  if (!parsed.success) {
    invalid(res, parsed.error.message);
    return;
  }
  const user = salesUser(req);
  const [row] = await db
    .insert(tasksTable)
    .values({
      ...parsed.data,
      dueAt: new Date(parsed.data.dueAt),
      ownerId: user.id,
      ownerName: user.name,
      branch: user.branch,
      team: user.team,
    })
    .returning();
  await addAudit(req, "create", "task", row.id);
  res.status(201).json(CreateTaskResponse.parse(row));
});

router.patch("/tasks/:id", async (req, res): Promise<void> => {
  const params = UpdateTaskParams.safeParse(req.params);
  const parsed = UpdateTaskBody.safeParse(req.body);
  if (!params.success) {
    invalid(res, params.error.message);
    return;
  }
  if (!parsed.success) {
    invalid(res, parsed.error.message);
    return;
  }
  const user = salesUser(req);
  const [existing] = await db.select().from(tasksTable).where(eq(tasksTable.id, params.data.id));
  if (!existing || !canReadScope(user, existing)) {
    res.status(404).json({ error: "Task not found" });
    return;
  }
  const requestedOwner = parsed.data.ownerId;
  if (
    requestedOwner &&
    requestedOwner !== existing.ownerId &&
    !canReassignOwner(user, existing)
  ) {
    res.status(403).json({ error: "لا تملك صلاحية تغيير مالك المتابعة" });
    return;
  }
  let newName: string | undefined;
  if (requestedOwner && requestedOwner !== existing.ownerId) {
    newName = await ownerDisplayName(user, requestedOwner) ?? undefined;
    if (!newName) {
      res.status(400).json({ error: "المستخدم المحدد غير نشط أو غير موجود" });
      return;
    }
  }
  const { dueAt, ownerId, ownerName: _ownerName, ...rest } = parsed.data;
  const [row] = await db
    .update(tasksTable)
    .set({
      ...rest,
      ...(dueAt ? { dueAt: new Date(dueAt) } : {}),
      ...(ownerId ? { ownerId } : {}),
      ...(newName ? { ownerName: newName } : {}),
    })
    .where(eq(tasksTable.id, params.data.id))
    .returning();
  await addAudit(req, "update", "task", row.id);
  res.json(UpdateTaskResponse.parse(row));
});

router.get("/quotes", async (req, res): Promise<void> => {
  const user = salesUser(req);
  const all = await db.select().from(quotesTable);
  const rows =
    user.role === "system_admin" ||
    user.role === "sales_manager" ||
    user.role === "team_leader" ||
    user.role === "pricing_officer"
      ? all.filter((row) => canReadScope(user, row) || user.role === "pricing_officer")
      : all.filter((row) => row.ownerId === user.id);
  res.json(ListQuotesResponse.parse(rows));
});

router.post("/quotes", async (req, res): Promise<void> => {
  const parsed = CreateQuoteBody.safeParse(req.body);
  if (!parsed.success) {
    invalid(res, parsed.error.message);
    return;
  }
  const user = salesUser(req);
  const [row] = await db
    .insert(quotesTable)
    .values({
      ...parsed.data,
      ownerId: user.id,
      ownerName: user.name,
      branch: user.branch,
      team: user.team,
      expiresAt: parsed.data.expiresAt ? new Date(parsed.data.expiresAt) : null,
    })
    .returning();
  await addAudit(req, "create", "quote", row.id);
  res.status(201).json(CreateQuoteResponse.parse(row));
});

router.patch("/quotes/:id", async (req, res): Promise<void> => {
  const params = UpdateQuoteParams.safeParse(req.params);
  const parsed = UpdateQuoteBody.safeParse(req.body);
  if (!params.success) {
    invalid(res, params.error.message);
    return;
  }
  if (!parsed.success) {
    invalid(res, parsed.error.message);
    return;
  }
  const user = salesUser(req);
  const [existing] = await db.select().from(quotesTable).where(eq(quotesTable.id, params.data.id));
  const allowed =
    existing &&
    ((user.role === "system_admin") ||
      (user.role === "sales_manager" && existing.ownerId === user.id) ||
      (user.role === "team_leader" && existing.ownerId === user.id) ||
      (user.role === "pricing_officer" && ["requested", "pricing"].includes(existing.status)) ||
      existing.ownerId === user.id);
  if (!existing || !allowed) {
    res.status(404).json({ error: "Quote not found" });
    return;
  }
  const { expiresAt, ownerId: requestedOwner, ownerName: _ownerName, ...rest } = parsed.data;
  if (requestedOwner && requestedOwner !== existing.ownerId) {
    res.status(403).json({ error: "تغيير مالك العرض يتطلب تفويضاً إدارياً" });
    return;
  }
  const [row] = await db
    .update(quotesTable)
    .set({
      ...rest,
      ...(expiresAt !== undefined ? { expiresAt: expiresAt ? new Date(expiresAt) : null } : {}),
    })
    .where(eq(quotesTable.id, params.data.id))
    .returning();
  await addAudit(req, "update", "quote", row.id);
  res.json(UpdateQuoteResponse.parse(row));
});

router.get("/renewals", async (req, res): Promise<void> => {
  const user = salesUser(req);
  const rows = filterScope(user, await db.select().from(renewalsTable));
  res.json(ListRenewalsResponse.parse(rows));
});

router.patch("/renewals/:id", async (req, res): Promise<void> => {
  const params = UpdateRenewalParams.safeParse(req.params);
  const parsed = UpdateRenewalBody.safeParse(req.body);
  if (!params.success) {
    invalid(res, params.error.message);
    return;
  }
  if (!parsed.success) {
    invalid(res, parsed.error.message);
    return;
  }
  const user = salesUser(req);
  const [existing] = await db.select().from(renewalsTable).where(eq(renewalsTable.id, params.data.id));
  if (!existing || !canReadScope(user, existing)) {
    res.status(404).json({ error: "Renewal not found" });
    return;
  }
  const {
    ownerId,
    ownerName: _ownerName,
    renewalDate,
    ...safeData
  } = parsed.data;
  if (ownerId && ownerId !== existing.ownerId) {
    if (!canReassignOwner(user, existing)) {
      res.status(403).json({ error: "لا تملك صلاحية تغيير مالك التجديد" });
      return;
    }
    const newName = await ownerDisplayName(user, ownerId);
    if (!newName) {
      res.status(400).json({ error: "المستخدم المحدد غير نشط أو غير موجود" });
      return;
    }
    const [row] = await db
      .update(renewalsTable)
      .set({
        ...safeData,
        ownerId,
        ownerName: newName,
        ...(renewalDate
          ? { renewalDate: renewalDate.toISOString().slice(0, 10) }
          : {}),
      })
      .where(eq(renewalsTable.id, params.data.id))
      .returning();
    await addAudit(req, "update", "renewal", row.id);
    res.json(UpdateRenewalResponse.parse(row));
    return;
  }
  const [row] = await db
    .update(renewalsTable)
    .set({
      ...safeData,
      ...(renewalDate
        ? { renewalDate: renewalDate.toISOString().slice(0, 10) }
        : {}),
    })
    .where(eq(renewalsTable.id, params.data.id))
    .returning();
  await addAudit(req, "update", "renewal", row.id);
  res.json(UpdateRenewalResponse.parse(row));
});

router.get("/commissions", async (req, res): Promise<void> => {
  const user = salesUser(req);
  if (!canViewCommissionDetail(user) && !["sales_executive", "business_development"].includes(user.role)) {
    res.status(403).json({ error: "بيانات العمولات التفصيلية متاحة للمالية والموظف المعني فقط" });
    return;
  }
  const rows = await db.select().from(commissionsTable);
  const visible =
    user.role === "system_admin" || user.role === "finance"
      ? rows
      : rows.filter((row) => row.employeeId === user.id);
  res.json(ListCommissionsResponse.parse(visible));
});

router.get("/approvals", async (req, res): Promise<void> => {
  const user = salesUser(req);
  const rows = await db.select().from(approvalsTable).orderBy(desc(approvalsTable.createdAt));
  const visible = rows.filter((row) =>
    canManageApprovals(user)
      ? canReadScope(user, row)
      : row.requesterId === user.id,
  );
  res.json(ListApprovalsResponse.parse(visible));
});

router.patch("/approvals/:id", async (req, res): Promise<void> => {
  const params = UpdateApprovalParams.safeParse(req.params);
  const parsed = UpdateApprovalBody.safeParse(req.body);
  if (!params.success) {
    invalid(res, params.error.message);
    return;
  }
  if (!parsed.success) {
    invalid(res, parsed.error.message);
    return;
  }
  const user = salesUser(req);
  if (!canManageApprovals(user)) {
    res.status(403).json({ error: "لا تملك صلاحية اتخاذ قرار في الطلبات" });
    return;
  }
  const [existing] = await db.select().from(approvalsTable).where(eq(approvalsTable.id, params.data.id));
  if (!existing || !canReadScope(user, existing)) {
    res.status(404).json({ error: "Approval not found" });
    return;
  }
  if (existing.status !== "pending") {
    res.status(409).json({ error: "تم اتخاذ قرار بشأن هذا الطلب مسبقاً" });
    return;
  }
  const [row] = await db
    .update(approvalsTable)
    .set({ status: parsed.data.status })
    .where(eq(approvalsTable.id, params.data.id))
    .returning();
  await addAudit(req, parsed.data.status, "approval", row.id);
  res.json(UpdateApprovalResponse.parse(row));
});

router.get("/activities", async (req, res): Promise<void> => {
  const user = salesUser(req);
  const rows = await db.select().from(activitiesTable).orderBy(desc(activitiesTable.occurredAt));
  const visible = rows.filter((row) =>
    canReadTeamActivity(user) ? canReadScope(user, row) : row.ownerId === user.id,
  );
  res.json(ListActivitiesResponse.parse(visible));
});

router.post("/activities", async (req, res): Promise<void> => {
  const parsed = CreateActivityBody.safeParse(req.body);
  if (!parsed.success) {
    invalid(res, parsed.error.message);
    return;
  }
  const user = salesUser(req);
  let clientName = parsed.data.clientName ?? null;
  if (parsed.data.clientId) {
    const [client] = await db.select().from(clientsTable).where(eq(clientsTable.id, parsed.data.clientId));
    if (!client || !canReadScope(user, client)) {
      res.status(404).json({ error: "Client not found" });
      return;
    }
    clientName = client.name;
  }
  const [row] = await db
    .insert(activitiesTable)
    .values({
      ...parsed.data,
      clientName,
      ownerId: user.id,
      ownerName: user.name,
      branch: user.branch,
      team: user.team,
    })
    .returning();
  await addAudit(req, "create", "activity", row.id);
  res.status(201).json(CreateActivityResponse.parse(row));
});

router.get("/audit", async (req, res): Promise<void> => {
  const user = salesUser(req);
  if (user.role === "top_management" || user.role === "system_admin") {
    const rows = await db.select().from(auditEntriesTable).orderBy(desc(auditEntriesTable.createdAt)).limit(200);
    res.json(ListAuditEntriesResponse.parse(rows));
    return;
  }
  const rows = await db.select().from(auditEntriesTable).orderBy(desc(auditEntriesTable.createdAt)).limit(300);
  let visible = rows.filter((row) => row.actorId === user.id);
  if (["sales_manager", "team_leader"].includes(user.role)) {
    const actors = await db.select().from(usersTable);
    const actorMap = new Map(actors.map((actor) => [actor.id, actor]));
    visible = rows.filter((row) => {
      const actor = actorMap.get(row.actorId);
      return actor ? canReadScope(user, actor) : row.actorId === user.id;
    });
  }
  res.json(ListAuditEntriesResponse.parse(visible));
});

router.get("/users", async (req, res): Promise<void> => {
  const user = salesUser(req);
  const rows = await db.select().from(usersTable);
  const visible = rows.filter((row) =>
    ["system_admin", "sales_manager", "team_leader"].includes(user.role)
      ? canReadScope(user, row)
      : row.id === user.id,
  );
  res.json(ListUsersResponse.parse(visible));
});

router.patch("/users/:id/role", async (req, res): Promise<void> => {
  const params = UpdateUserRoleParams.safeParse(req.params);
  const parsed = UpdateUserRoleBody.safeParse(req.body);
  if (!params.success) {
    invalid(res, params.error.message);
    return;
  }
  if (!parsed.success) {
    invalid(res, parsed.error.message);
    return;
  }
  const user = salesUser(req);
  if (!canManageRoles(user)) {
    res.status(403).json({ error: "تعديل الأدوار متاح لمدير النظام فقط" });
    return;
  }
  if (!roleValues.includes(parsed.data.role as (typeof roleValues)[number])) {
    res.status(400).json({ error: "الدور المحدد غير معروف" });
    return;
  }
  if (params.data.id === user.id && parsed.data.role !== "system_admin") {
    res.status(409).json({ error: "لا يمكن إزالة صلاحية مدير النظام من حسابك الحالي" });
    return;
  }
  const [row] = await db
    .update(usersTable)
    .set({
      role: parsed.data.role,
      ...(parsed.data.branch ? { branch: parsed.data.branch } : {}),
      ...(parsed.data.team ? { team: parsed.data.team } : {}),
    })
    .where(eq(usersTable.id, params.data.id))
    .returning();
  if (!row) {
    res.status(404).json({ error: "User not found" });
    return;
  }
  await addAudit(req, "change_role", "user", 0);
  res.json(UpdateUserRoleResponse.parse(row));
});

router.get("/reports", async (req, res): Promise<void> => {
  const user = salesUser(req);
  const [clients, opportunities, renewals, commissions] = await Promise.all([
    db.select().from(clientsTable),
    db.select().from(opportunitiesTable),
    db.select().from(renewalsTable),
    db.select().from(commissionsTable),
  ]);
  const scopedClients = filterScope(user, clients);
  const scopedOpportunities = filterScope(user, opportunities);
  const scopedRenewals = filterScope(user, renewals);
  const scopedCommissions =
    user.role === "system_admin" || user.role === "finance"
      ? commissions
      : commissions.filter((row) => row.employeeId === user.id);
  const value: ReportSummary = {
    totalClients: scopedClients.length,
    openOpportunities: scopedOpportunities.filter((row) => !["won", "lost"].includes(row.stage)).length,
    weightedPipeline: scopedOpportunities
      .filter((row) => !["won", "lost"].includes(row.stage))
      .reduce((sum, row) => sum + row.premium * (row.probability / 100), 0),
    revenueThisMonth: scopedCommissions
      .filter((row) => row.period === new Date().toISOString().slice(0, 7))
      .reduce((sum, row) => sum + row.grossAmount, 0),
    renewalsDue: scopedRenewals.filter((row) => row.status === "upcoming" || row.status === "in_progress").length,
    commissionsPending: canReadFinancialDetail(user) || canViewCommissionDetail(user)
      ? scopedCommissions.filter((row) => row.status === "pending").reduce((sum, row) => sum + row.grossAmount, 0)
      : 0,
  };
  res.json(GetReportsResponse.parse(value));
});

router.get("/integrations", async (req, res): Promise<void> => {
  const user = salesUser(req);
  if (!["system_admin", "sales_manager", "top_management"].includes(user.role)) {
    res.status(403).json({ error: "لا تملك صلاحية عرض إعدادات التكامل" });
    return;
  }
  const rows = await db.select().from(businessIntegrationsTable);
  res.json(ListIntegrationsResponse.parse(rows));
});

export default router;
