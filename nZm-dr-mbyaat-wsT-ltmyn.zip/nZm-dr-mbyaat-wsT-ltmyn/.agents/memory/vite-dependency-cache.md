---
name: Vite dependency cache
description: Recovering from stale optimized React bundles after workspace dependency changes.
---

When React or React DOM versions change in a workspace package, the app's Vite development optimizer can retain old versions in its artifact-local `.vite` cache. A workflow restart alone may continue serving those stale bundles and produce a React version mismatch even when pnpm resolves matching versions.

**Why:** In October 2026, Clerk's React peer range required React 19.1.4 while the shared workspace catalog remained at 19.1.0 for Expo. Pinning matching 19.1.4 versions in the web artifact was insufficient until its optimized-dependency cache was cleared.

**How to apply:** Verify the package graph with `pnpm why react react-dom`; if resolved versions match but browser bundles still disagree, remove only the affected artifact's `node_modules/.vite` cache and restart that artifact's workflow.
